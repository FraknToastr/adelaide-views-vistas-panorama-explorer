"""Persistent origin, reprojection guards, and local-to-projected XY conversion.

Origin settings are stored as decimal *strings*, not RNA FloatProperty, because
single-precision RNA/UI floats cannot reliably retain 6,134,xxx m northings
at sub-metre precision. Coordinates are computed with Python double floats.
"""
import math
import json
import os
import re

import bpy
from bpy.props import BoolProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup

CRS = 'EPSG:7854'
LABEL = 'GDA2020 / MGA Zone 54 (EPSG:7854)'
_META = ('geolod_origin_e', 'geolod_origin_n', 'geolod_origin_h')


def external_viewpoint_info(points_path):
    """Read optional user-supplied EPSG:7854 point SHP; no bundled data required."""
    from .views import load_shapefile
    points_path = bpy.path.abspath(points_path)
    if not points_path or not os.path.isfile(points_path):
        raise ValueError('Choose an existing external Viewpoints .shp file')
    validate_prj(points_path)
    for shape, attributes in load_shapefile(points_path):
        if not shape or shape.get('type') != 'POINT':
            continue
        x, y = shape['point']
        if not (math.isfinite(x) and math.isfinite(y) and
                100_000 < x < 900_000 and 5_000_000 < y < 9_000_000):
            raise ValueError('Invalid external viewpoint EPSG:7854 coordinates')
        return {'easting': float(x), 'northing': float(y),
                'view_id': str(attributes.get('VIEW_ID') or '(no VIEW_ID)'),
                'filename': os.path.basename(points_path)}
    raise ValueError('External viewpoints dataset has no active point geometry')


def parse_xyz(text, label):
    try:
        val = float(str(text).strip())
    except (TypeError, ValueError) as e:
        raise ValueError(f'{label} must be a decimal number') from e
    if not math.isfinite(val):
        raise ValueError(f'{label} must be finite')
    return val


def parse_input(settings):
    x = parse_xyz(settings.origin_easting, 'Origin easting')
    y = parse_xyz(settings.origin_northing, 'Origin northing')
    z = parse_xyz(settings.origin_height, 'Origin height')
    if not 100_000 < x < 900_000 or not 5_000_000 < y < 9_000_000:
        raise ValueError('Origin outside expected Australian MGA projected-metre range')
    return x, y, z


def anchor(scene):
    if not has_anchor(scene):
        raise ValueError('Commit the scene geospatial origin before registering LOD/building views')
    return tuple(parse_xyz(scene[k], k) for k in _META)


def has_anchor(scene):
    return scene.get('geolod_crs') == CRS and all(k in scene for k in _META)


def local_coords(scene, x, y, z):
    ox, oy, oz = anchor(scene)
    return float(x) - ox, float(y) - oy, float(z) - oz


def scene_busy(scene):
    return bool(scene.geolod_registered_lod or scene.geolod_edit_positions or
                scene.geolod_registration_active or scene.geolod_edit_active or
                bpy.data.collections.get('AVV_Generated'))


def validate_prj(shp_path):
    """Strictly accept matching projected WKT; this is NOT a CRS transformer."""
    path = os.path.splitext(shp_path)[0] + '.prj'
    if not os.path.isfile(path):
        raise ValueError(f'Missing .prj sidecar for {os.path.basename(shp_path)}; CRS cannot be verified')
    with open(path, 'r', encoding='utf-8-sig', errors='replace') as f:
        wkt = f.read().upper()
    if not (('GDA2020' in wkt or 'GEOCENTRIC_DATUM_OF_AUSTRALIA_2020' in wkt) and
            ('ZONE_54' in wkt or 'ZONE 54' in wkt or 'EPSG",7854' in wkt or '7854]' in wkt) and
            ('TRANSVERSE_MERCATOR' in wkt or 'TRANSVERSE MERCATOR' in wkt) and
            ('METRE' in wkt or 'METER' in wkt)):
        raise ValueError(f'{os.path.basename(shp_path)} is not verified as EPSG:7854; reproject in GIS first')
    # WKT1 often has no EPSG authority; test zone and projection text.
    return True


class GeoLODSettings(PropertyGroup):
    # Tool 2 RNA properties. These MUST be declared on GeoLODSettings because
    # the operators/UI read them from Scene.geolod_settings. Leaving them out
    # caused AttributeError after Use Active as Reference in v1.1.0.
    lod_collection: PointerProperty(
        name='LOD Collection', type=bpy.types.Collection,
        description='Collection containing the entire LOD (including child collections); selection in the Outliner alone does not set this field')
    reference_object: PointerProperty(
        name='Reference Model', type=bpy.types.Object,
        description='LOD reference object; the temporary edit anchor can use its visible geometry bounds instead of its object origin')
    lod_edit_anchor: bpy.props.EnumProperty(
        name='Temporary edit anchor',
        description='Which point on the reference model should be moved to scene (0,0,0)',
        items=[
            ('GEOMETRY', 'Reference geometry centre', 'Centre of the reference mesh world-space bounding box; handles meshes with origins at 0,0,0 and remote vertices'),
            ('ORIGIN', 'Reference object origin', 'Use the reference object world-space origin; only when the origin is meaningful'),
            ('CURSOR', '3D Cursor location', 'Use the current 3D Cursor position; snap to a mesh vertex in Edit Mode for precision'),
        ], default='GEOMETRY')
    origin_easting: StringProperty(name='Origin Easting (m)', default='')
    origin_northing: StringProperty(name='Origin Northing (m)', default='')
    origin_height: StringProperty(name='Origin Height (m)', default='0.0')
    control_easting: StringProperty(name='Control Easting (m)', default='')
    control_northing: StringProperty(name='Control Northing (m)', default='')
    control_height: StringProperty(name='Control Height (m)', default='0.0')
    origin_source: bpy.props.EnumProperty(
        name='Origin source',
        items=[
            ('MANUAL', 'Manual coordinates', 'Enter a projected scene origin; no shapefiles required'),
            ('EXTERNAL', 'External viewpoint SHP', 'Read first valid point from a user-selected EPSG:7854 shapefile'),
        ], default='MANUAL')
    viewpoint_source: StringProperty(name='Viewpoints SHP', subtype='FILE_PATH',
                                    description='Optional external shapefile used to choose Tool 1 origin')
    # Registered LOD model coordinate conventions; no hidden CRS guessing.
    lod_mode: bpy.props.EnumProperty(
        name='LOD alignment mode',
        items=[
            ('PROJECTED', 'Already projected (E,N,H)', 'Existing LOD geometry uses EPSG:7854 easting/northing world coordinates in metres'),
            ('CONTROL', 'Known control point (surveyed)', 'Tie a 3D cursor point to its surveyed EPSG:7854 easting, northing and height'),
            ('LOCAL', 'Already scene-local (E-E0, N-N0)', 'Only use when the imported LOD has already been correctly transformed into the Tool 1 local origin; does not alter coordinates'),
            ('EDIT_ONLY', 'Preserve imported position (edit only)', 'Do not change or claim to georeference the LOD; only move the full collection temporarily to edit and restore'),
        ], default='EDIT_ONLY')


class GEOLOD_OT_CommitOrigin(Operator):
    bl_idname = 'geolod.commit_origin'
    bl_label = 'Commit Scene Origin'
    bl_description = 'Fix a shared EPSG:7854 local origin in the .blend file'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if has_anchor(scene) or scene_busy(scene):
            self.report({'ERROR'}, 'Existing geospatial content or origin present; clear/unregister it before committing a new origin')
            return {'CANCELLED'}
        settings = scene.geolod_settings
        try:
            sources = scene.avv_settings
            points = bpy.path.abspath(sources.points_shp)
            cones = bpy.path.abspath(sources.cones_shp)
            if not os.path.isfile(points) or not os.path.isfile(cones):
                raise ValueError('Choose both Views & Vistas shapefiles in Tool 1')
            validate_prj(points)
            validate_prj(cones)
            point = external_viewpoint_info(points)
            # Check that the second file is genuinely a polygon dataset.
            from .views import load_shapefile
            if not any(shape and shape.get('type') == 'POLYGON'
                       for shape, record in load_shapefile(cones)):
                raise ValueError('The Views & Vistas polygon shapefile has no active polygons')
            xyz = (point['easting'], point['northing'], 0.0)
            origin_source = 'EXTERNAL'
        except (OSError, ValueError, KeyError) as e:
            self.report({'ERROR'}, 'Cannot commit origin: ' + str(e)[:160])
            return {'CANCELLED'}
        for key, v in zip(_META, xyz):
            scene[key] = repr(v)
        scene['geolod_origin_source'] = origin_source
        if point:
            scene['geolod_origin_view_id'] = point['view_id']
            scene['geolod_origin_source_file'] = point['filename']
        scene['geolod_crs'] = CRS
        scene['geolod_units'] = 'metres'
        scene['geolod_convention'] = 'local = projected - scene_origin; X east Y north Z up'
        self.report({'INFO'}, 'Committed GDA2020 / MGA Zone 54 local origin to scene')
        return {'FINISHED'}


class GEOLOD_OT_ResetOrigin(Operator):
    bl_idname = 'geolod.reset_origin'
    bl_label = 'Reset Scene Origin'
    bl_description = 'Clear reference only after all tracked LOD models and generated shapes are removed'
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        if scene_busy(scene):
            self.report({'ERROR'}, 'First clear Views & Vistas and restore/unregister LOD before resetting origin')
            return {'CANCELLED'}
        for key in (*_META, 'geolod_crs', 'geolod_units', 'geolod_convention',
                    'geolod_origin_source', 'geolod_origin_view_id',
                    'geolod_origin_source_file'):
            if key in scene:
                del scene[key]
        self.report({'INFO'}, 'Cleared scene geospatial anchor')
        return {'FINISHED'}


class GEOLOD_OT_CursorLocation(Operator):
    bl_idname = 'geolod.cursor_location'
    bl_label = 'Inspect Cursor Georeference'
    bl_description = 'Show projected EPSG:7854 coordinates of the Blender 3D cursor'
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            ox, oy, oz = anchor(context.scene)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        local = context.scene.cursor.location
        east, north, height = float(local.x) + ox, float(local.y) + oy, float(local.z) + oz
        # String metadata avoids rounding 6.1 million metres down to UI float precision.
        context.scene['geolod_cursor_readout'] = f'E {east:.3f}  N {north:.3f}  H {height:.3f}  ({CRS})'
        self.report({'INFO'}, context.scene['geolod_cursor_readout'])
        return {'FINISHED'}


class GEOLOD_OT_ExportReference(Operator):
    bl_idname = 'geolod.export_reference'
    bl_label = 'Export Georeference JSON'
    bl_description = 'Save a local-to-EPSG:7854 transform sidecar for exported 3D assets'
    bl_options = {'REGISTER'}

    filepath: StringProperty(name='Save JSON', subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        if not has_anchor(context.scene):
            self.report({'ERROR'}, 'Commit scene geospatial origin first')
            return {'CANCELLED'}
        if not self.filepath:
            self.filepath = bpy.path.abspath('//Adelaide_GeoLOD_Georeference.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        from .lod import registered
        if context.scene.geolod_edit_positions or context.scene.geolod_edit_active:
            self.report({'ERROR'}, 'Restore temporarily centred LOD before exporting spatial reference')
            return {'CANCELLED'}
        try:
            ox, oy, oz = anchor(context.scene)
            path = bpy.path.abspath(self.filepath)
            if not path.lower().endswith('.json'):
                path += '.json'
            scene = context.scene
            root = bpy.data.collections.get('AVV_Generated')
            payload = {
                'format': 'Adelaide-GeoLOD-Reference-1.0',
                'crs': CRS,
                'units': 'metres',
                'axes': 'X east, Y north, Z up',
                'local_to_projected': {
                    'easting_m': 'local_X + origin_easting_m',
                    'northing_m': 'local_Y + origin_northing_m',
                    'height_m': 'local_Z + origin_height_m',
                    'origin_easting_m': repr(ox),
                    'origin_northing_m': repr(oy),
                    'origin_height_m': repr(oz),
                },
                'registered_lod': sorted(obj.name for obj in registered(scene)),
                'lod_alignment_mode': scene.geolod_registration_mode if scene.geolod_registration_active else None,
                'lod_spatial_alignment_verified': False,
                'lod_alignment_note': ('Edit-only registration: original LOD placement was preserved; '
                    'the LOD has NOT been georeferenced to this scene origin.'
                    if scene.geolod_registration_active and scene.geolod_registration_mode == 'EDIT_ONLY' else
                    'LOD alignment mode describes the user-selected method; actual spatial agreement '
                    'must be independently verified using surveyed/control data.'),
                'generated_views_vistas_count': len(root.all_objects) if root else 0,
                'generated_views_vistas_frame': root.get('lod_source_frame') if root else None,
                'generated_views_vistas_attached_to_lod': bool(root.get('geolod_attached_to_lod')) if root else False,
                'generated_views_vistas_original_coordinate_formula': (
                    'projected_E,N,H = object_X,Y,Z (only after full Tool 2 restore)'
                    if root and root.get('lod_source_frame') == 'RAW_ENH'
                    else 'projected_E,N,H = object_X,Y,Z + Tool1 scene origin (only after full Tool 2 restore)'),
                'generated_views_vistas_alignment_verified': False,
                'cautions': [
                    'This file describes the spatial transform; it does not reproject 3D geometry',
                    'Confirm the vertical datum and source LOD CRS independently',
                    'Scene origin and generated Views & Vistas geometry alone do not prove that the LOD is georeferenced',
                    'A 3D format export is not automatically GIS-georeferenced without applying this transform',
                    'When generated in RAW_ENH, do NOT add Tool 1 origin to Views & Vistas coordinates again',
                ],
            }
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(payload, f, indent=2)
        except (OSError, ValueError) as exc:
            self.report({'ERROR'}, 'Reference export failed: ' + str(exc)[:170])
            return {'CANCELLED'}
        self.report({'INFO'}, 'Saved georeference JSON sidecar')
        return {'FINISHED'}


class GEOLOD_PT_Reference(Panel):
    bl_label = '1. Spatial Data'
    bl_idname = 'GEOLOD_PT_scene_reference'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Adelaide GeoLOD'
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        s = scene.avv_settings
        layout.prop(s, 'points_shp', text='Viewpoints')
        layout.prop(s, 'cones_shp', text='Views & Vistas')
        if has_anchor(scene):
            layout.label(text='Origin set', icon='CHECKMARK')
        else:
            layout.operator('geolod.commit_origin', text='Set Scene Origin', icon='CHECKMARK')


CLASSES = (GeoLODSettings, GEOLOD_OT_CommitOrigin, GEOLOD_OT_ResetOrigin,
           GEOLOD_OT_CursorLocation,
           GEOLOD_OT_ExportReference, GEOLOD_PT_Reference)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.geolod_settings = PointerProperty(type=GeoLODSettings)


def unregister():
    if hasattr(bpy.types.Scene, 'geolod_settings'):
        del bpy.types.Scene.geolod_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
