"""External Views & Vistas shapefile parser and Blender geometry construction."""
import bpy
import os
import math
import struct
from types import SimpleNamespace
from . import georef, lod
from mathutils import Vector
from bpy.props import (
    StringProperty, FloatProperty, BoolProperty, PointerProperty, EnumProperty,
)
from bpy.types import Operator, Panel, PropertyGroup

# -----------------------------------------------------------------------------
# Minimal SHP / DBF reader - no external Python packages required
# Supports Point and Polygon shapefiles used by this project.
# -----------------------------------------------------------------------------

def _read_dbf(path, encoding="cp1252"):
    with open(path, "rb") as f:
        header = f.read(32)
        if len(header) < 32:
            raise ValueError("Invalid DBF header")
        num_records = struct.unpack("<I", header[4:8])[0]
        header_len = struct.unpack("<H", header[8:10])[0]
        record_len = struct.unpack("<H", header[10:12])[0]

        fields = []
        while True:
            b = f.read(1)
            if not b:
                raise ValueError("Unexpected end of DBF field descriptors")
            if b == b"\r":
                break
            desc = b + f.read(31)
            name = desc[0:11].split(b"\x00", 1)[0].decode("ascii", "ignore").strip()
            ftype = chr(desc[11])
            length = desc[16]
            decimals = desc[17]
            fields.append((name, ftype, length, decimals))

        f.seek(header_len)
        records = []
        for _ in range(num_records):
            raw = f.read(record_len)
            if len(raw) < record_len:
                break
            if raw[0:1] == b"*":
                records.append(None)  # Keep SHP/DBF record indices aligned.
                continue
            pos = 1
            row = {}
            for name, ftype, length, decimals in fields:
                chunk = raw[pos:pos+length]
                pos += length
                txt = chunk.decode(encoding, "replace").strip()
                if txt == "":
                    val = None
                elif ftype in ("N", "F"):
                    try:
                        val = float(txt) if (decimals or "." in txt) else int(txt)
                    except Exception:
                        val = None
                elif ftype == "L":
                    val = txt.upper() in ("Y", "T")
                else:
                    val = txt
                row[name] = val
            records.append(row)
        return records


def _read_shp(path):
    with open(path, "rb") as f:
        head = f.read(100)
        if len(head) < 100:
            raise ValueError("Invalid SHP header")
        shape_type = struct.unpack("<i", head[32:36])[0]
        shapes = []
        while True:
            rec_header = f.read(8)
            if not rec_header:
                break
            if len(rec_header) < 8:
                break
            _rec_no, content_words = struct.unpack(">2i", rec_header)
            content = f.read(content_words * 2)
            if len(content) < 4:
                continue
            st = struct.unpack("<i", content[0:4])[0]
            if st == 0:
                shapes.append(None)
                continue
            if st == 1:  # Point
                x, y = struct.unpack("<2d", content[4:20])
                shapes.append({"type": "POINT", "point": (x, y)})
            elif st == 5:  # Polygon
                num_parts, num_points = struct.unpack("<2i", content[36:44])
                off = 44
                parts = list(struct.unpack("<" + "i" * num_parts, content[off:off + 4*num_parts]))
                off += 4 * num_parts
                pts = []
                for i in range(num_points):
                    x, y = struct.unpack("<2d", content[off + i*16: off + i*16 + 16])
                    pts.append((x, y))
                rings = []
                for i, start in enumerate(parts):
                    end = parts[i+1] if i+1 < len(parts) else len(pts)
                    ring = pts[start:end]
                    if len(ring) > 2 and ring[0] == ring[-1]:
                        ring = ring[:-1]
                    if len(ring) >= 3:
                        rings.append(ring)
                shapes.append({"type": "POLYGON", "rings": rings})
            else:
                shapes.append({"type": "UNSUPPORTED", "shape_type": st})
        return shape_type, shapes


def load_shapefile(path):
    if not path or not os.path.exists(path):
        raise FileNotFoundError(path or "No shapefile selected")
    dbf = os.path.splitext(path)[0] + ".dbf"
    if not os.path.exists(dbf):
        raise FileNotFoundError("Matching DBF not found: " + dbf)
    _stype, shapes = _read_shp(path)
    records = _read_dbf(dbf)
    n = min(len(shapes), len(records))
    return [(shapes[i], records[i]) for i in range(n) if records[i] is not None]


# -----------------------------------------------------------------------------
# Geometry helpers
# -----------------------------------------------------------------------------

def clean_num(v, default=None):
    if v is None:
        return default
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("°", "")
    if not s:
        return default
    try:
        return float(s)
    except Exception:
        return default


def safe_name(s):
    s = str(s or "unnamed")
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in s)[:63]


def get_or_create_collection(name, parent=None):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        if parent:
            parent.children.link(coll)
        else:
            bpy.context.scene.collection.children.link(coll)
    return coll


def make_material(name, rgba):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = rgba
        bsdf.inputs["Alpha"].default_value = rgba[3]
        bsdf.inputs["Roughness"].default_value = 0.45
    if rgba[3] < 0.999:
        if hasattr(mat, "surface_render_method"):
            try:
                mat.surface_render_method = 'DITHERED'
            except Exception:
                pass
        if hasattr(mat, "blend_method"):
            try:
                mat.blend_method = 'BLEND'
            except Exception:
                pass
        if hasattr(mat, "use_transparency_overlap"):
            mat.use_transparency_overlap = False
    return mat


def local_xy(x, y, ox, oy, scale):
    return ((x - ox) * scale, (y - oy) * scale)


def make_mesh_object(name, verts, faces, collection, material=None):
    mesh = bpy.data.meshes.new(name + "_Mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    if material:
        obj.data.materials.append(material)
    return obj


def create_viewshed(rings, rec, settings, collection, material):
    view_id = rec.get("VIEW_ID", "View")
    cone_no = rec.get("CONE_NO", "")
    ground_z = clean_num(rec.get("ALTITUDE_1"), settings.default_ground_z)
    z = (ground_z - settings.origin_z) * settings.z_scale + settings.viewshed_offset
    made = []
    for idx, ring in enumerate(rings):
        verts = []
        for x, y in ring:
            lx, ly = local_xy(x, y, settings.origin_x, settings.origin_y, settings.xy_scale)
            verts.append((lx, ly, z))
        if len(verts) < 3:
            continue
        name = f"Viewshed_{safe_name(view_id)}_{cone_no}_{idx+1}"
        obj = make_mesh_object(name, verts, [tuple(range(len(verts)))], collection, material)
        obj["VIEW_ID"] = str(view_id)
        obj["CONE_NO"] = str(cone_no)
        obj["PARK_NAME"] = str(rec.get("PARK_NAME") or "")
        obj["source_type"] = "viewshed"
        obj["geolod_generated"] = True
        obj["geo_crs"] = georef.CRS
        made.append(obj)
    return made


def frustum_geometry(px, py, ground_z, eye_h, bearing_deg, distance, hfov_deg, vfov_deg, settings):
    # Blender local axes: +X east, +Y north, +Z up.
    # Bearing is clockwise from north.
    eye_z = (ground_z + eye_h - settings.origin_z) * settings.z_scale
    dist = max(0.01, distance * settings.xy_scale)
    hfov = math.radians(max(0.1, min(179.0, hfov_deg)))
    vfov = math.radians(max(0.1, min(179.0, vfov_deg)))
    b = math.radians(bearing_deg)

    forward = Vector((math.sin(b), math.cos(b), 0.0)).normalized()
    right = Vector((forward.y, -forward.x, 0.0)).normalized()
    up = Vector((0.0, 0.0, 1.0))

    half_w = math.tan(hfov * 0.5) * dist
    half_h = math.tan(vfov * 0.5) * dist
    apex = Vector((px, py, eye_z))
    center = apex + forward * dist

    # Lower vertices can be clamped to the flat ground reference so the mesh
    # does not visibly continue below ground when no terrain object is present.
    ground_local = (ground_z - settings.origin_z) * settings.z_scale + settings.frustum_ground_clearance
    z_low = center.z - half_h
    if settings.clamp_frustum_to_ground:
        z_low = max(z_low, ground_local)
    z_high = center.z + half_h

    fl = Vector((center.x, center.y, z_low)) - right * half_w
    fr = Vector((center.x, center.y, z_low)) + right * half_w
    tl = Vector((center.x, center.y, z_high)) - right * half_w
    tr = Vector((center.x, center.y, z_high)) + right * half_w

    verts = [tuple(apex), tuple(fl), tuple(fr), tuple(tr), tuple(tl)]
    # Open-bottom wedge: no lower triangular face. This prevents a large buried
    # face while preserving the sides, top, and far plane.
    faces = [
        (0, 2, 3),
        (0, 3, 4),
        (0, 4, 1),
        (1, 4, 3, 2),
    ]
    return verts, faces


def create_point_and_frustums(shape, rec, settings, points_coll, frustums_coll, point_mat, frustum_mat):
    x, y = shape["point"]
    lx, ly = local_xy(x, y, settings.origin_x, settings.origin_y, settings.xy_scale)
    ground_z = clean_num(rec.get("ALTITUDE_1"), settings.default_ground_z)
    eye_h = clean_num(rec.get("ELEVATION"), settings.default_eye_height)
    view_id = rec.get("VIEW_ID", "View")

    # True spatial point geometry: an icosphere object in the scene.
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=2,
        radius=settings.point_radius,
        location=(lx, ly, (ground_z - settings.origin_z) * settings.z_scale + settings.point_radius),
    )
    p_obj = bpy.context.active_object
    p_obj.name = f"Point_{safe_name(view_id)}"
    # Move object into our collection only.
    for c in list(p_obj.users_collection):
        c.objects.unlink(p_obj)
    points_coll.objects.link(p_obj)
    p_obj.data.materials.append(point_mat)
    p_obj["VIEW_ID"] = str(view_id)
    p_obj["PARK_NAME"] = str(rec.get("PARK_NAME") or "")
    p_obj["ground_elevation_m"] = ground_z
    # Absolute survey XY as precise decimal strings, not Blender FloatProperty.
    p_obj["geo_crs"] = georef.CRS
    p_obj["geo_easting_m"] = repr(x)
    p_obj["geo_northing_m"] = repr(y)
    p_obj["geolod_generated"] = True
    p_obj["eye_height_m"] = eye_h
    p_obj["source_type"] = "viewpoint"

    if not settings.create_frustums:
        return p_obj, []

    fr_objs = []
    for i in range(1, 6):
        bearing = clean_num(rec.get(f"BEARING{i}"))
        dist = clean_num(rec.get(f"DIST{i}"))
        hfov = clean_num(rec.get(f"HFOV{i}"))
        vfov = clean_num(rec.get(f"VFOV{i}"))
        if None in (bearing, dist, hfov):
            continue
        if vfov is None:
            vfov = settings.default_vfov
        verts, faces = frustum_geometry(
            lx, ly, ground_z, eye_h, bearing, dist, hfov, vfov, settings
        )
        name = f"Frustum_{safe_name(view_id)}_{i}"
        obj = make_mesh_object(name, verts, faces, frustums_coll, frustum_mat)
        obj["VIEW_ID"] = str(view_id)
        obj["PARK_NAME"] = str(rec.get("PARK_NAME") or "")
        obj["vector_index"] = i
        obj["bearing_deg"] = bearing
        obj["distance_m"] = dist
        obj["hfov_deg"] = hfov
        obj["vfov_deg"] = vfov
        obj["source_type"] = "frustum"
        obj["geolod_generated"] = True
        obj["geo_crs"] = georef.CRS
        obj["geo_easting_m"] = repr(x)
        obj["geo_northing_m"] = repr(y)
        fr_objs.append(obj)
    return p_obj, fr_objs


# -----------------------------------------------------------------------------
# Add-on settings / operators
# -----------------------------------------------------------------------------
class AVVSettings(PropertyGroup):
    points_shp: StringProperty(name="Viewpoints SHP", subtype='FILE_PATH')
    cones_shp: StringProperty(name="Viewsheds SHP", subtype='FILE_PATH')

    lod_source_frame: EnumProperty(
        name='LOD source coordinate frame',
        description='How the imported LOD was originally positioned before temporary editing; does not reproject data',
        items=[
            ('SCENE_LOCAL', 'Scene-local: E minus Tool 1 origin',
             'Use when the imported LOD is already in the Tool 1 local metre frame'),
            ('RAW_ENH', 'Raw MGA54: original Easting/Northing/Height',
             'Use only when LOD mesh coordinates are raw EPSG:7854 projected metres; no Tool 1 origin subtraction'),
        ], default='SCENE_LOCAL')

    filter_enabled: BoolProperty(name="Only one VIEW_ID", default=False)
    filter_view_id: StringProperty(name="VIEW_ID", default="TorRiv.R")


    default_ground_z: FloatProperty(name="Default ground elevation", default=0.0)
    default_eye_height: FloatProperty(name="Default eye height", default=1.6, min=0.0)
    default_vfov: FloatProperty(name="Default VFOV", default=60.0, min=0.1, max=179.0)
    point_radius: FloatProperty(name="Point radius", default=0.75, min=0.01)
    viewshed_offset: FloatProperty(name="Viewshed Z offset", default=0.05)
    frustum_ground_clearance: FloatProperty(name="Frustum ground clearance", default=0.03)

    create_points: BoolProperty(name="Points", default=True)
    create_viewsheds: BoolProperty(name="Viewsheds", default=True)
    create_frustums: BoolProperty(name="Frustums", default=True)
    clamp_frustum_to_ground: BoolProperty(name="Clamp lower frustum to ground", default=True)


def remove_generated_collection(name):
    root = bpy.data.collections.get(name)
    if root is None:
        return
    for obj in list(root.all_objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    for child in list(root.children):
        bpy.data.collections.remove(child)
    bpy.data.collections.remove(root)


class AVV_OT_clear_generated(Operator):
    bl_idname = "avv.clear_generated"
    bl_label = "Clear Generated Views & Vistas"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        remove_generated_collection('AVV_Generated')
        if hasattr(context.scene, 'geolod_edit_generated_collection'):
            context.scene.geolod_edit_generated_collection = None
        self.report({'INFO'}, 'Cleared generated Views & Vistas objects; registered LOD preserved')
        return {'FINISHED'}


def output_origin_for_frame(scene, frame):
    """Choose the coordinates represented by the imported LOD before editing.

    SCENE_LOCAL stores (E-E0,N-N0,H-H0); RAW_ENH stores (E,N,H).
    Neither choice can *prove* LOD georeferencing without source metadata.
    """
    origin = Vector(georef.anchor(scene))
    if frame == 'SCENE_LOCAL':
        return origin
    if frame == 'RAW_ENH':
        if scene.geolod_registration_active and scene.geolod_registration_mode != 'EDIT_ONLY':
            raise ValueError('Raw MGA54 frame is only available with Preserve Imported Position (edit only). Other registration modes already convert the LOD to scene-local coordinates')
        return Vector((0.0, 0.0, 0.0))
    raise ValueError('Unsupported imported LOD coordinate frame: ' + str(frame))


def temporary_offset(scene):
    """Shared LOD edit translation, independent of the generated geometry."""
    if scene.geolod_edit_positions:
        raise ValueError('Restore legacy LOD temporary positions before building geometry')
    if scene.geolod_edit_active:
        if not scene.geolod_registration_active:
            raise ValueError('The LOD editing state is inconsistent: no full-collection registration')
        return lod.geolod_edit_delta(scene)
    raise ValueError('Move LOD to Origin in Tool 2 before building Views & Vistas')


def check_near_edit_reference(scene, point_rows, origin, offset, frame):
    """Guard against accidentally creating geometry millions of metres away.

    This is just a gross-placement safeguard, *not* an accuracy or CRS test.
    """
    if not scene.geolod_edit_active or not point_rows:
        return
    ref = scene.geolod_reference_object
    if ref is None:
        raise ValueError('Registered LOD reference object is unavailable')
    try:
        reference = lod.mesh_bounds_centre(ref)
    except ValueError:
        reference = ref.matrix_world.translation.copy()
    closest = min(math.hypot((float(sh['point'][0])-origin.x+offset.x)-reference.x,
                             (float(sh['point'][1])-origin.y+offset.y)-reference.y)
                  for sh, _rec in point_rows)
    if not math.isfinite(closest) or closest > 200000:
        other = 'Raw MGA54' if frame == 'SCENE_LOCAL' else 'Scene-local'
        raise ValueError(f'Views are at least {closest/1000:,.0f} km from the LOD reference using {frame}; check LOD CRS or choose {other} in Tool 3. Nothing was built')


def infer_lod_source_frame(scene, point_rows):
    """Infer imported LOD frame from its original anchor and survey points.

    Selection uses horizontal proximity and gross 200 km safeguards, not
    an assertion that a particular building is surveyed correctly. It never
    guesses a coordinate transformation or height datum.
    """
    if not point_rows:
        raise ValueError('No viewpoints available for spatial alignment')
    if not scene.geolod_registration_active:
        raise ValueError('Prepare the LOD in Tool 2 before building Views & Vistas')
    ref = scene.geolod_reference_object
    if ref is None:
        raise ValueError('LOD reference building is no longer available')
    try:
        current = lod.mesh_bounds_centre(ref)
    except ValueError:
        raise ValueError('Reference building mesh is missing; select a mesh building')
    edit_offset = temporary_offset(scene)
    original = current - edit_offset
    scene_origin = Vector(georef.anchor(scene))
    candidates = {}
    for frame, shift in (('RAW_ENH', Vector((0.0,0.0,0.0))),
                         ('SCENE_LOCAL', scene_origin)):
        d = min(math.hypot(float(sh['point'][0])-shift.x-original.x,
                           float(sh['point'][1])-shift.y-original.y)
                for sh, _ in point_rows)
        candidates[frame] = d
    chosen = min(candidates, key=candidates.get)
    alternative = next(k for k in candidates if k != chosen)
    if candidates[chosen] > 200_000:
        raise ValueError('LOD position does not match the shapefile coordinates. Check the model CRS before building')
    # Robust distinction between ~6.1-million northing and local ~0 values.
    if candidates[alternative] <= 200_000 and candidates[alternative] < max(1.0, candidates[chosen]) * 10:
        raise ValueError('LOD coordinate frame is ambiguous; check imported model georeferencing')
    return chosen


class AVV_OT_build(Operator):
    bl_idname = "avv.build"
    bl_label = "Build Spatial Geometry"
    bl_description = "Create georeferenced local-space point, polygon and view frustum meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode before building Views & Vistas geometry')
            return {'CANCELLED'}
        scene = context.scene
        s = scene.avv_settings
        try:
            edit_delta = temporary_offset(scene)
            ox, oy, oz = georef.anchor(scene)
            pp = bpy.path.abspath(s.points_shp)
            cp = bpy.path.abspath(s.cones_shp)
            georef.validate_prj(pp)
            georef.validate_prj(cp)
            points = load_shapefile(pp)
            cones = load_shapefile(cp)
        except Exception as e:
            self.report({'ERROR'}, str(e)[:190])
            return {'CANCELLED'}

        point_rows = [(sh, rec) for sh, rec in points if sh and sh.get('type') == 'POINT']
        cone_rows = [(sh, rec) for sh, rec in cones if sh and sh.get('type') == 'POLYGON']
        if not point_rows:
            self.report({'ERROR'}, 'No matching point records found')
            return {'CANCELLED'}
        if not cone_rows:
            self.report({'ERROR'}, 'No matching viewshed records found')
            return {'CANCELLED'}
        try:
            frame = infer_lod_source_frame(scene, point_rows)
            frame_origin = output_origin_for_frame(scene, frame)
            check_near_edit_reference(scene, point_rows, frame_origin, edit_delta, frame)
            # Use internal hidden geometry defaults irrespective of old .blend
            # settings. Keep the prior properties for project compatibility.
            internal = dict(
                default_ground_z=0.0, default_eye_height=1.6,
                default_vfov=60.0, point_radius=0.75,
                viewshed_offset=0.05, frustum_ground_clearance=0.03,
                create_points=True, create_viewsheds=True,
                create_frustums=True, clamp_frustum_to_ground=True,
                origin_x=frame_origin.x - edit_delta.x,
                origin_y=frame_origin.y - edit_delta.y,
                origin_z=frame_origin.z - edit_delta.z,
                xy_scale=1.0, z_scale=1.0)
            cfg = SimpleNamespace(**internal)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc)[:250])
            return {'CANCELLED'}

        # Stage in a separate collection, so a bad source record never destroys
        # an earlier successful generation. No LOD geometry is touched.
        stage_name = 'AVV_Generated_STAGING'
        if bpy.data.collections.get(stage_name) is not None:
            self.report({'ERROR'}, 'Staging collection already exists. Inspect and remove it manually')
            return {'CANCELLED'}
        root = None
        try:
            root = bpy.data.collections.new(stage_name)
            context.scene.collection.children.link(root)
            points_coll = get_or_create_collection('AVV_Points_STAGING', root)
            views_coll = get_or_create_collection('AVV_Viewsheds_STAGING', root)
            frust_coll = get_or_create_collection('AVV_Frustums_STAGING', root)
            point_mat = make_material('AVV_Point_Cyan', (0.02, 0.8, 1.0, 1.0))
            views_mat = make_material('AVV_Viewshed_Green', (0.1, 0.8, 0.25, 0.35))
            frust_mat = make_material('AVV_Frustum_Orange', (1.0, 0.28, 0.03, 0.22))
            point_count = fr_count = view_count = 0
            for sh, rec in point_rows:
                p, fs = create_point_and_frustums(sh, rec, cfg, points_coll, frust_coll, point_mat, frust_mat)
                point_count += 1 if p else 0
                fr_count += len(fs)
            for sh, rec in cone_rows:
                made = create_viewshed(sh['rings'], rec, cfg, views_coll, views_mat)
                view_count += len(made)
            # No post-generation translation: the temporary frame was applied
            # to source coordinates BEFORE creating mesh vertices. Tool 2 will
            # reverse the offset on the separate AVV collection at restoration.
            root['source_crs'] = georef.CRS
            root['origin_easting_m'] = repr(ox)
            root['origin_northing_m'] = repr(oy)
            root['origin_height_m'] = repr(oz)
            root['horizontal_units'] = 'metres'
            root['local_formula'] = ('world = projected - Tool1_origin' if frame == 'SCENE_LOCAL'
                                     else 'world = raw_projected_ENH')
            root['lod_source_frame'] = frame
            root['geolod_attached_to_lod'] = bool(scene.geolod_edit_active)
            root['generated_in_temporary_edit'] = bool(scene.geolod_edit_active)
            root['temporary_edit_translation'] = lod.serialize_vec(edit_delta) if scene.geolod_edit_active else ''
            root['lod_alignment_verified'] = False
            root['vertical_note'] = 'Ground Z from ALTITUDE_1 or fallback; vertical datum unverified'
        except Exception as exc:
            if root is not None:
                try:
                    remove_generated_collection(stage_name)
                except Exception:
                    pass
            self.report({'ERROR'}, 'Generation failed; previous geometry retained: ' + str(exc)[:130])
            return {'CANCELLED'}

        # Swap only after the complete staging build has succeeded. Keep the
        # previous generated collection intact if a rename step raises.
        old = bpy.data.collections.get('AVV_Generated')
        backup_name = 'AVV_Generated_BACKUP'
        if bpy.data.collections.get(backup_name) is not None:
            self.report({'ERROR'}, 'Backup collection name is occupied; remove AVV_Generated_BACKUP manually before rebuilding')
            return {'CANCELLED'}
        try:
            if old is not None:
                old.name = backup_name
                for child in old.children:
                    child.name = child.name + '_BACKUP'
            root.name = 'AVV_Generated'
            points_coll.name = 'AVV_Points'
            views_coll.name = 'AVV_Viewsheds'
            frust_coll.name = 'AVV_Frustums'
        except Exception as exc:
            if old is not None:
                try:
                    old.name = 'AVV_Generated'
                except Exception:
                    pass
            self.report({'ERROR'}, 'Generated staging preserved; collection swap failed: ' + str(exc)[:140])
            return {'CANCELLED'}
        # The saved pointer identifies exactly which generated collection must
        # follow the LOD's inverse edit translation, without linking it into
        # the main LOD collection (which would duplicate movement).
        if scene.geolod_edit_active:
            scene.geolod_edit_generated_collection = root
        if old is not None:
            remove_generated_collection(backup_name)
        attachment = 'attached to active LOD restoration' if scene.geolod_edit_active else 'placed in selected source frame'
        self.report({'INFO'}, f'Created {point_count} points, {view_count} viewsheds, {fr_count} frustums; {attachment}')
        return {'FINISHED'}


class AVV_PT_panel(Panel):
    bl_idname = 'AVV_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Adelaide GeoLOD'
    bl_label = '3. Views & Vistas'
    bl_order = 3

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        row = layout.row()
        row.enabled = (georef.has_anchor(scene) and scene.geolod_edit_active
                       and bool(scene.avv_settings.points_shp) and bool(scene.avv_settings.cones_shp))
        row.operator('avv.build', text='Build Views & Vistas', icon='MESH_CONE')
        if bpy.data.collections.get('AVV_Generated'):
            layout.operator('avv.clear_generated', text='Clear Views & Vistas', icon='TRASH')


classes = (
    AVVSettings,
    AVV_OT_clear_generated,
    AVV_OT_build,
    AVV_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.avv_settings = PointerProperty(type=AVVSettings)


def unregister():
    if hasattr(bpy.types.Scene, "avv_settings"):
        del bpy.types.Scene.avv_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
