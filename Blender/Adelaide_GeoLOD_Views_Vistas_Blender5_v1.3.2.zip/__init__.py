"""Adelaide GeoLOD: shared spatial frame for LOD and Views & Vistas geometry."""
from . import georef, lod, views, export_obj


def register():
    georef.register()
    lod.register()
    views.register()
    export_obj.register()


def unregister():
    export_obj.unregister()
    views.unregister()
    lod.unregister()
    georef.unregister()
