"""Adelaide-focused workflow regression tests (mock Blender; no installation required)."""
import importlib
import os
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _mock_group_lod as mocks
import _mock_temporal_views as view_mocks
MockObject, Vector, approx = mocks.MockObject, mocks.Vector, mocks.approx

pkg=importlib.import_module(Path(__file__).resolve().parent.parent.name)
lod, views, georef=pkg.lod,pkg.views,pkg.georef
import bpy


class StreamlinedAdelaideWorkflow(unittest.TestCase):
    def setUp(self):
        t=mocks.FullLODTest(); t.setUp()
        self.t=t
        self.scene=t.scene
        self.ctx=t.context
        self.scene.collection=types.SimpleNamespace(children=view_mocks.LinkList())
        self.scene.geolod_edit_generated_collection=None
        self.s=types.SimpleNamespace(points_shp='viewpoints.shp', cones_shp='viewcones.shp',
                                     lod_source_frame='SCENE_LOCAL',
                                     create_points=False, create_viewsheds=False, create_frustums=False,
                                     filter_enabled=True, filter_view_id='none')
        self.scene.avv_settings=self.s
        self.registry=view_mocks.CollectionRegistry()
        self.patch_col=patch.object(bpy.data,'collections',self.registry)
        self.patch_col.start(); self.addCleanup(self.patch_col.stop)
        self.obj_reg=types.SimpleNamespace(remove=self.remove_object)
        self.patch_obj=patch.object(bpy.data,'objects',self.obj_reg,create=True)
        self.patch_obj.start(); self.addCleanup(self.patch_obj.stop)
        # Mock objects are empty transform-only. Substitute their positions for
        # bounding-box mesh centres in these transform-focused tests.
        self.patch_bounds=patch.object(lod,'mesh_bounds_centre',side_effect=lambda obj:obj.matrix_world.translation.copy())
        self.patch_bounds.start(); self.addCleanup(self.patch_bounds.stop)
        self.points=[({'type':'POINT', 'point':(t.origin.x+52,t.origin.y+203)},
                      {'VIEW_ID':'CHECK','ALTITUDE_1':10,'ELEVATION':1.6})]
        self.cones=[({'type':'POLYGON','rings':[[(t.origin.x+50,t.origin.y+200),
                                               (t.origin.x+60,t.origin.y+200),
                                               (t.origin.x+60,t.origin.y+210)]]},
                     {'VIEW_ID':'CHECK','ALTITUDE_1':10})]

    def remove_object(self, obj, do_unlink=True):
        if obj in self.scene.objects:self.scene.objects.remove(obj)
        for c in list(obj.users_collection): c.objects.unlink(obj)

    def fake_point(self, sh, rec, cfg, point_coll, frust_coll, *materials):
        x,y=sh['point']; obj=MockObject('Point_1',(x-cfg.origin_x,y-cfg.origin_y,10-cfg.origin_z))
        obj._custom['geolod_generated']=True
        self.scene.objects.append(obj); point_coll.objects.link(obj)
        return obj, []

    def fake_viewshed(self, rings, rec, cfg, coll, material):
        p=rings[0][0];obj=MockObject('Viewshed_1',(p[0]-cfg.origin_x,p[1]-cfg.origin_y,10-cfg.origin_z))
        obj._custom['geolod_generated']=True
        self.scene.objects.append(obj); coll.objects.link(obj)
        return [obj]

    def build(self):
        def load(path):return self.points if 'viewpoints' in path else self.cones
        with patch.object(georef,'validate_prj',return_value=True),\
             patch.object(views,'load_shapefile',side_effect=load),\
             patch.object(views,'make_material',return_value=None),\
             patch.object(views,'create_point_and_frustums',side_effect=self.fake_point),\
             patch.object(views,'create_viewshed',side_effect=self.fake_viewshed):
            return views.AVV_OT_build().execute(self.ctx)

    def begin(self):
        # Selecting one object must configure entire collection and fixed modes.
        self.ctx.active_object=self.t.anchor
        self.scene.geolod_settings.lod_collection=None
        self.assertEqual(lod.GEOLOD_OT_UseActiveReference().execute(self.ctx),{'FINISHED'})
        self.assertIs(self.scene.geolod_settings.lod_collection,self.t.collection)
        self.assertEqual(self.scene.geolod_settings.lod_mode,'EDIT_ONLY')
        self.assertEqual(self.scene.geolod_settings.lod_edit_anchor,'GEOMETRY')
        self.assertEqual(lod.GEOLOD_OT_RegisterLOD().execute(self.ctx),{'FINISHED'})
        self.assertEqual(self.scene.geolod_registration_mode,'EDIT_ONLY')
        self.assertEqual(lod.GEOLOD_OT_EditLODAtOrigin().execute(self.ctx),{'FINISHED'})

    def test_raw_mga_build_restore(self):
        self.begin()
        self.assertEqual(self.build(),{'FINISHED'})
        col=self.registry.get('AVV_Generated')
        self.assertEqual(col.get('lod_source_frame'),'RAW_ENH')
        self.assertIs(self.scene.geolod_edit_generated_collection,col)
        point=next(o for o in col.all_objects if o.name.startswith('Point_'))
        approx(point.matrix_world.translation,(2,3,-2))
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.ctx),{'FINISHED'})
        approx(point.matrix_world.translation,(self.t.origin.x+52,self.t.origin.y+203,10))
        approx(self.t.anchor.matrix_world.translation,self.t.before[self.t.anchor])
        self.assertIsNone(self.scene.geolod_edit_generated_collection)
        self.assertEqual(lod.GEOLOD_OT_EditLODAtOrigin().execute(self.ctx),{'FINISHED'})
        approx(point.matrix_world.translation,(2,3,-2))
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.ctx),{'FINISHED'})

    def test_already_local_build_restore(self):
        # Emulate an LOD imported already at Tool 1 local coordinates.
        lod.translate_group(self.ctx,{self.t.anchor,self.t.child,self.t.other},-self.t.origin)
        self.begin()
        self.assertEqual(self.build(),{'FINISHED'})
        col=self.registry.get('AVV_Generated')
        self.assertEqual(col.get('lod_source_frame'),'SCENE_LOCAL')
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.ctx),{'FINISHED'})
        point=next(o for o in col.all_objects if o.name.startswith('Point_'))
        approx(point.matrix_world.translation,(52,203,10))

    def test_no_silent_mismatch(self):
        # Other CRS or wrong import scale cannot be inferred from two datasets.
        lod.translate_group(self.ctx,{self.t.anchor,self.t.child,self.t.other},Vector((1000000,1000000,0)))
        self.begin()
        self.assertEqual(self.build(),{'CANCELLED'})
        self.assertIsNone(self.registry.get('AVV_Generated'))
        self.assertTrue(self.scene.geolod_edit_active)

    def test_rebuild_replaces_and_clears(self):
        self.begin()
        self.assertEqual(self.build(),{'FINISHED'})
        old=self.registry.get('AVV_Generated')
        self.assertEqual(self.build(),{'FINISHED'})
        new=self.registry.get('AVV_Generated')
        self.assertIsNot(new,old)
        self.assertIs(self.scene.geolod_edit_generated_collection,new)
        self.assertNotIn(old,self.registry.entries)
        self.assertEqual(views.AVV_OT_clear_generated().execute(self.ctx),{'FINISHED'})
        self.assertIsNone(self.scene.geolod_edit_generated_collection)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.ctx),{'FINISHED'})

    def test_single_button_registers_entire_collection(self):
        self.scene.geolod_settings.lod_collection = None
        self.scene.geolod_settings.lod_mode = 'PROJECTED' # old saved setting
        self.assertEqual(lod.GEOLOD_OT_RegisterSelectedLOD().execute(self.ctx), {'FINISHED'})
        self.assertIs(self.scene.geolod_registered_collection, self.t.collection)
        self.assertEqual(len(self.scene.geolod_registered_lod), 3)
        self.assertEqual(self.scene.geolod_registration_mode, 'EDIT_ONLY')

    def test_one_click_registration_never_instantiates_blender_operators(self):
        # Real Blender bpy_struct operators cannot be created as Operator().
        # In the original v1.2.0 this produced a TypeError in Tool 2.
        self.scene.geolod_settings.lod_collection = None
        with (patch.object(lod.GEOLOD_OT_UseActiveReference, '__new__',
                          side_effect=TypeError('bpy_struct.__new__: expected a single argument')),
             patch.object(lod.GEOLOD_OT_RegisterLOD, '__new__',
                          side_effect=TypeError('bpy_struct.__new__: expected a single argument'))):
            self.assertEqual(lod.GEOLOD_OT_RegisterSelectedLOD().execute(self.ctx), {'FINISHED'})
        self.assertTrue(self.scene.geolod_registration_active)
        self.assertEqual(len(self.scene.geolod_registered_lod), 3)
        self.assertIs(self.scene.geolod_registered_collection, self.t.collection)

    def test_one_click_registration_requires_active_lod_building(self):
        self.ctx.active_object = None
        self.ctx.selected_objects = []
        self.assertEqual(lod.GEOLOD_OT_RegisterSelectedLOD().execute(self.ctx), {'CANCELLED'})
        self.assertFalse(self.scene.geolod_registration_active)
        self.assertEqual(len(self.scene.geolod_registered_lod), 0)

    def test_one_click_registration_rejects_second_call(self):
        self.assertEqual(lod.GEOLOD_OT_RegisterSelectedLOD().execute(self.ctx), {'FINISHED'})
        self.assertEqual(lod.GEOLOD_OT_RegisterSelectedLOD().execute(self.ctx), {'CANCELLED'})
        self.assertEqual(len(self.scene.geolod_registered_lod), 3)

    def test_new_independent_object_returns_with_lod(self):
        self.begin()
        newborn=MockObject('Added mesh',(3,4,5))
        self.scene.objects.append(newborn)
        self.t.collection.objects.link(newborn)
        self.assertEqual(self.build(), {'FINISHED'})
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.ctx),{'FINISHED'})
        approx(newborn.matrix_world.translation,
               (self.t.origin.x+53,self.t.origin.y+204,17))
        self.assertIn(newborn,lod.registered(self.scene))

    def test_collection_scale_8200_objects(self):
        # Registration/movement/restoration of a realistic city-wide model.
        added=[]
        for i in range(8197):
            item=MockObject('Building_%05d'%i,
                            (self.t.origin.x+(i%70),self.t.origin.y+(i//70),10))
            added.append(item)
            self.scene.objects.append(item)
            self.t.collection.objects.link(item)
        before={o: o.matrix_world.translation.copy() for o in added}
        self.begin()
        self.assertEqual(len(self.scene.geolod_registered_lod), 8200)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.ctx), {'FINISHED'})
        for o in added:
            approx(o.matrix_world.translation,before[o])

    def test_two_files_required_before_origin(self):
        # Simulate fresh project without committed origin.
        for k in ('geolod_crs','geolod_origin_e','geolod_origin_n','geolod_origin_h'):
            del self.scene[k]
        with patch.object(georef.os.path,'isfile',return_value=True),\
             patch.object(georef,'validate_prj',return_value=True),\
             patch.object(georef,'external_viewpoint_info',return_value={'easting':self.t.origin.x,'northing':self.t.origin.y,'view_id':'A','filename':'viewpoints.shp'}),\
             patch.object(views,'load_shapefile',return_value=self.cones):
            self.assertEqual(georef.GEOLOD_OT_CommitOrigin().execute(self.ctx),{'FINISHED'})
        self.assertTrue(georef.has_anchor(self.scene))

    def test_minimal_ui_no_dropdown_properties(self):
        import inspect
        for panel in (lod.GEOLOD_PT_LOD,georef.GEOLOD_PT_Reference,views.AVV_PT_panel):
            src=inspect.getsource(panel.draw)
            for old in ('lod_mode','lod_edit_anchor','lod_source_frame','origin_source','filter_view_id','VIEW_ID:','E: ','N: '):
                self.assertNotIn(old,src)
        self.assertNotIn('settings_box',inspect.getsource(lod.GEOLOD_PT_LOD.draw))

if __name__=='__main__':unittest.main(verbosity=2)
