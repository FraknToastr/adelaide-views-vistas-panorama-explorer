"""Mock Blender regression tests. Run: python qa/test_group_lod.py (no Blender required)."""
import importlib
import math
import os
import sys
import types
import unittest
from pathlib import Path

PKGDIR = Path(__file__).resolve().parent.parent


class Vector:
    def __init__(self, values): self.v = [float(v) for v in values]
    def __getitem__(self, k): return self.v[k]
    def __iter__(self): return iter(self.v)
    def __getattr__(self, key):
        if key in ('x', 'y', 'z'): return self.v['xyz'.index(key)]
        raise AttributeError(key)
    def __add__(self, other): return Vector(a + b for a, b in zip(self, other))
    def __sub__(self, other): return Vector(a - b for a, b in zip(self, other))
    def __neg__(self): return Vector(-a for a in self)
    def copy(self): return Vector(self)
    @property
    def length_squared(self): return sum(x*x for x in self)
    def __repr__(self): return repr(self.v)


class Matrix:
    def __init__(self, vec): self.translation = Vector(vec)
    def copy(self): return Matrix(self.translation)
    def __matmul__(self, point): return self.translation + Vector(point)


class MockObject:
    type = 'MESH'
    bound_box = ((0,0,0),)*8
    data = types.SimpleNamespace(vertices=[1])
    is_editable = True
    library = None
    constraints = ()
    animation_data = None
    def __init__(self, name, xyz, parent=None):
        self.name, self.parent = name, parent
        self._local = Vector(xyz) - (parent.matrix_world.translation if parent else Vector((0,0,0)))
        self.users_collection = []
        self._custom = {}
    @property
    def matrix_world(self):
        return Matrix(self._local + (self.parent.matrix_world.translation if self.parent else Vector((0,0,0))))
    @matrix_world.setter
    def matrix_world(self, matrix):
        self._local = matrix.translation - (self.parent.matrix_world.translation if self.parent else Vector((0,0,0)))
    def get(self, key, default=None): return self._custom.get(key, default)
    def select_set(self, val): self._selected = val


class Objects(list):
    def __init__(self, col): super().__init__(); self.col = col
    def link(self, obj):
        if obj not in self: self.append(obj)
        if self.col not in obj.users_collection: obj.users_collection.append(self.col)
    def unlink(self, obj):
        if obj in self: self.remove(obj)
        if self.col in obj.users_collection: obj.users_collection.remove(self.col)


class Collection:
    def __init__(self, name): self.name=name; self.objects=Objects(self)
    @property
    def all_objects(self): return list(self.objects)


class Rows(list):
    def add(self):
        row=types.SimpleNamespace(object_ref=None, initial_world_pos='', original_world_pos='')
        self.append(row)
        return row
    def clear(self): self[:] = []


class Scene(dict):
    def __init__(self, objects, settings):
        super().__init__()
        self.objects=objects
        self.geolod_settings=settings
        self.geolod_registered_lod=Rows()
        self.geolod_edit_positions=Rows()
        self.geolod_registered_collection=None
        self.geolod_reference_object=None
        self.geolod_registration_delta=''
        self.geolod_registration_active=False
        self.geolod_edit_delta=''
        self.geolod_edit_anchor_used=''
        self.geolod_edit_active=False
        self.cursor=types.SimpleNamespace(location=Vector((0,0,0)))
        self['geolod_crs']='EPSG:7854'
        self['geolod_origin_e']='281849.6765341535'
        self['geolod_origin_n']='6134404.409386028'
        self['geolod_origin_h']='0'


class Context:
    def __init__(self, scene, active):
        self.scene=scene
        self.active_object=active
        self.selected_objects=[active]
        self.mode='OBJECT'
        self.view_layer=types.SimpleNamespace(update=lambda: None)


def install_fake():
    bpy=types.ModuleType('bpy')
    bpy.props=types.ModuleType('bpy.props')
    for f in ('BoolProperty','CollectionProperty','PointerProperty','StringProperty','EnumProperty','FloatProperty'):
        setattr(bpy.props, f, lambda **kwargs: None)
    bpy.types=types.ModuleType('bpy.types')
    for n in ('Operator','Panel','PropertyGroup','Scene','Object','Collection'):
        setattr(bpy.types, n, type(n, (), {}))
    bpy.types.Operator.report=lambda self,*args: None
    bpy.utils=types.SimpleNamespace(register_class=lambda x:None, unregister_class=lambda x:None)
    bpy.data=types.SimpleNamespace(collections=types.SimpleNamespace(get=lambda n:None))
    bpy.path=types.SimpleNamespace(abspath=lambda p:os.path.abspath(p))
    bpy.ops=types.SimpleNamespace(object=types.SimpleNamespace(select_all=lambda **kw: None))
    sys.modules.update({'bpy':bpy,'bpy.props':bpy.props,'bpy.types':bpy.types})
    mm=types.ModuleType('mathutils'); mm.Vector=Vector; sys.modules['mathutils']=mm


install_fake()
sys.path.insert(0, str(PKGDIR.parent))
package=importlib.import_module(PKGDIR.name)
lod=package.lod


def approx(actual, expected, eps=1e-5):
    assert all(abs(a-b) < eps for a,b in zip(actual,expected)), (actual,expected)


class FullLODTest(unittest.TestCase):
    def setUp(self):
        self.origin=Vector((281849.6765341535,6134404.409386028,0.0))
        anchor_xyz=self.origin + Vector((50,200,12))
        self.anchor=MockObject('Chosen model',anchor_xyz)
        self.child=MockObject('Child of chosen model',anchor_xyz+Vector((10,2,0)),self.anchor)
        self.other=MockObject('Unrelated LOD object',self.origin+Vector((300,180,10)))
        self.external=MockObject('Views & Vistas unregistered',self.origin + Vector((555,222,0)))
        self.collection=Collection('Full_LOD')
        for o in (self.anchor,self.child,self.other): self.collection.objects.link(o)
        self.settings=types.SimpleNamespace(lod_collection=self.collection,reference_object=self.anchor,
            lod_edit_anchor='ORIGIN',lod_mode='PROJECTED',control_easting='',control_northing='',control_height='')
        self.scene=Scene([self.anchor,self.child,self.other,self.external],self.settings)
        self.context=Context(self.scene,self.anchor)
        self.before={obj:obj.matrix_world.translation.copy() for obj in self.scene.objects}

    def run_op(self, cls):
        result=cls().execute(self.context)
        self.assertEqual(result, {'FINISHED'})

    def test_register_edit_restore_unregister_and_new_objects(self):
        self.run_op(lod.GEOLOD_OT_RegisterLOD)
        self.assertEqual(self.scene['geolod_crs'],'EPSG:7854')
        approx(self.anchor.matrix_world.translation,self.before[self.anchor])
        approx(self.child.matrix_world.translation,self.before[self.child])
        approx(self.other.matrix_world.translation,self.before[self.other])
        approx(self.external.matrix_world.translation,self.before[self.external])
        self.run_op(lod.GEOLOD_OT_EditLODAtOrigin)
        approx(self.anchor.matrix_world.translation,(0,0,0))
        approx(self.child.matrix_world.translation,(10,2,0))
        approx(self.other.matrix_world.translation,(250,-20,-2))
        # Edit an existing object and mesh object while near origin.
        moved=self.other.matrix_world.copy()
        moved.translation=moved.translation + Vector((2,3,5))
        self.other.matrix_world=moved
        # Create an independent object while temporarily at origin.
        newborn=MockObject('Edited LOD new geometry',(4,5,6))
        self.scene.objects.append(newborn)
        self.context.selected_objects=[newborn]
        self.run_op(lod.GEOLOD_OT_AddSelectedToLOD)
        self.assertIn(newborn,self.collection.all_objects)
        self.run_op(lod.GEOLOD_OT_RestoreEditedLOD)
        approx(self.anchor.matrix_world.translation,self.before[self.anchor])
        approx(self.child.matrix_world.translation,self.before[self.child])
        approx(self.other.matrix_world.translation,self.before[self.other]+Vector((2,3,5)))
        approx(newborn.matrix_world.translation,self.origin+Vector((54,205,18)))
        self.assertFalse(self.scene.geolod_edit_active)
        self.assertIn(newborn,lod.registered(self.scene))
        self.run_op(lod.GEOLOD_OT_UnregisterLOD)
        approx(self.other.matrix_world.translation,self.before[self.other]+Vector((2,3,5)))
        approx(newborn.matrix_world.translation,self.origin+Vector((54,205,18)))
        approx(self.external.matrix_world.translation,self.before[self.external])
        self.assertFalse(self.scene.geolod_registration_active)

    def test_parent_child_moved_once(self):
        self.run_op(lod.GEOLOD_OT_RegisterLOD)
        self.run_op(lod.GEOLOD_OT_EditLODAtOrigin)
        self.run_op(lod.GEOLOD_OT_RestoreEditedLOD)
        approx(self.child.matrix_world.translation,self.before[self.child])

    def test_missing_collected_object_blocks_restore(self):
        self.run_op(lod.GEOLOD_OT_RegisterLOD)
        self.run_op(lod.GEOLOD_OT_EditLODAtOrigin)
        self.collection.objects.unlink(self.other)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'CANCELLED'})
        self.assertTrue(self.scene.geolod_edit_active)

    def test_unlisted_child_prevents_partial_move(self):
        outsider=MockObject('Out of scope child',self.before[self.anchor]+Vector((1,0,0)),self.anchor)
        self.scene.objects.append(outsider)
        self.assertEqual(lod.GEOLOD_OT_RegisterLOD().execute(self.context), {'CANCELLED'})
        approx(self.anchor.matrix_world.translation,self.before[self.anchor])

    def test_generated_view_rejected(self):
        gen=MockObject('View',self.before[self.anchor])
        gen._custom['geolod_generated']=True
        self.collection.objects.link(gen)
        self.scene.objects.append(gen)
        self.assertEqual(lod.GEOLOD_OT_RegisterLOD().execute(self.context), {'CANCELLED'})

    def test_double_registration_and_edit_blocked(self):
        self.run_op(lod.GEOLOD_OT_RegisterLOD)
        self.assertEqual(lod.GEOLOD_OT_RegisterLOD().execute(self.context), {'CANCELLED'})
        self.run_op(lod.GEOLOD_OT_EditLODAtOrigin)
        self.assertEqual(lod.GEOLOD_OT_EditLODAtOrigin().execute(self.context), {'CANCELLED'})
        self.assertEqual(lod.GEOLOD_OT_UnregisterLOD().execute(self.context), {'CANCELLED'})

    def test_reference_changes_relative_not_average(self):
        self.run_op(lod.GEOLOD_OT_RegisterLOD)
        self.run_op(lod.GEOLOD_OT_EditLODAtOrigin)
        approx(self.anchor.matrix_world.translation,(0,0,0))
        approx(self.other.matrix_world.translation,(250,-20,-2))


if __name__ == '__main__': unittest.main(verbosity=2)
