"""End-to-end mock test: Tool 3 geometry joins Tool 2 temporary relocation.

Run: python qa/test_temporary_views_integration.py
This uses no Blender installation, so live Blender 5.x testing is still required.
"""
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _mock_group_lod import (FullLODTest, MockObject, Collection, Vector, approx)

import importlib
_pkg = importlib.import_module(Path(__file__).resolve().parent.parent.name)
lod, views = _pkg.lod, _pkg.views
import bpy


class LinkList(list):
    def link(self, item):
        if item not in self:
            self.append(item)


class GenCollection(Collection):
    def __init__(self, name):
        super().__init__(name)
        self.children = LinkList()
        self._props = {}

    def get(self, key, default=None):
        return self._props.get(key, default)

    def __setitem__(self, key, value):
        self._props[key] = value

    @property
    def all_objects(self):
        return list(self.objects) + [o for c in self.children for o in c.all_objects]


class CollectionRegistry:
    def __init__(self):
        self.entries = []

    def new(self, name):
        c = GenCollection(name)
        self.entries.append(c)
        return c

    def get(self, name):
        return next((c for c in self.entries if c.name == name), None)

    def remove(self, col):
        self.entries.remove(col)


class TemporaryBuildIntegration(unittest.TestCase):
    def setUp(self):
        self.base = FullLODTest()
        self.base.setUp()
        scene = self.base.scene
        self.scene = scene
        self.context = self.base.context
        self.base.settings.lod_mode = 'EDIT_ONLY'
        scene.geolod_registration_mode = ''
        scene.geolod_edit_generated_collection = None
        self.assertEqual(lod.GEOLOD_OT_RegisterLOD().execute(self.context), {'FINISHED'})
        self.assertEqual(lod.GEOLOD_OT_EditLODAtOrigin().execute(self.context), {'FINISHED'})
        self.registry = CollectionRegistry()
        self.scene.collection = types.SimpleNamespace(children=LinkList())
        self.points = [( {'type': 'POINT', 'point': (self.base.origin.x+52, self.base.origin.y+203)},
                         {'VIEW_ID': 'CHECK', 'ALTITUDE_1': 10} )]
        self.cones = [({'type':'POLYGON','rings':[[(self.base.origin.x+52,self.base.origin.y+203),
                          (self.base.origin.x+60,self.base.origin.y+203),
                          (self.base.origin.x+60,self.base.origin.y+208)]]},
                       {'VIEW_ID':'CHECK','ALTITUDE_1':10})]
        self.s = types.SimpleNamespace(
            points_shp='viewpoints.shp', cones_shp='viewsheds.shp', lod_source_frame='RAW_ENH',
            create_points=True, create_frustums=False, create_viewsheds=False,
            filter_enabled=False, filter_view_id='',
            bl_rna=types.SimpleNamespace(properties=[]))
        self.scene.avv_settings = self.s
        self.registry_patch = patch.object(bpy.data, 'collections', self.registry)
        self.registry_patch.start()
        self.addCleanup(self.registry_patch.stop)
        obj_registry = types.SimpleNamespace(remove=self.remove_object)
        self.objects_patch = patch.object(bpy.data, 'objects', obj_registry, create=True)
        self.objects_patch.start()
        self.addCleanup(self.objects_patch.stop)

    def remove_object(self, obj, do_unlink=True):
        if obj in self.scene.objects:
            self.scene.objects.remove(obj)
        for c in list(obj.users_collection):
            c.objects.unlink(obj)

    def fake_point(self, shape, rec, cfg, points_col, frustum_col, pmat, fmat):
        e, n = shape['point']
        obj = MockObject('View_' + rec['VIEW_ID'], (e-cfg.origin_x, n-cfg.origin_y, 10-cfg.origin_z))
        obj._custom['geolod_generated'] = True
        self.scene.objects.append(obj)
        points_col.objects.link(obj)
        return obj, []

    def fake_viewshed(self, rings, rec, cfg, coll, material):
        e, n = rings[0][0]
        obj = MockObject('Viewshed_' + rec['VIEW_ID'],
                         (e-cfg.origin_x,n-cfg.origin_y,10-cfg.origin_z))
        obj._custom['geolod_generated'] = True
        self.scene.objects.append(obj)
        coll.objects.link(obj)
        return [obj]

    def build(self):
        def load(path):
            return self.points if 'viewpoints' in path else self.cones
        with (patch.object(views, 'load_shapefile', side_effect=load),
              patch.object(views.georef, 'validate_prj', return_value=True),
              patch.object(views, 'make_material', return_value=None),
              patch.object(views, 'create_point_and_frustums', side_effect=self.fake_point),
              patch.object(views, 'create_viewshed', side_effect=self.fake_viewshed)):
            return views.AVV_OT_build().execute(self.context)

    def test_build_raw_while_editing_and_restore_both(self):
        self.assertEqual(self.build(), {'FINISHED'})
        root = self.registry.get('AVV_Generated')
        self.assertIs(self.scene.geolod_edit_generated_collection, root)
        self.assertTrue(root.get('geolod_attached_to_lod'))
        self.assertEqual(root.get('lod_source_frame'), 'RAW_ENH')
        point = root.all_objects[0]
        approx(point.matrix_world.translation, (2, 3, -2))
        self.assertNotIn(point, self.base.collection.all_objects)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'FINISHED'})
        approx(point.matrix_world.translation, (self.base.origin.x+52, self.base.origin.y+203, 10))
        self.assertIsNone(self.scene.geolod_edit_generated_collection)
        approx(self.base.anchor.matrix_world.translation, self.base.before[self.base.anchor])

    def test_misaligned_lod_frame_is_rejected_without_generated_objects(self):
        # Source frame is detected automatically; shifting reference far outside
        # the plausible area must be rejected without generating anything.
        lod.translate_group(self.context, {self.base.anchor, self.base.child, self.base.other}, Vector((500_000,500_000,0)))
        self.assertEqual(self.build(), {'CANCELLED'})
        self.assertIsNone(self.registry.get('AVV_Generated'))
        self.assertTrue(self.scene.geolod_edit_active)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'FINISHED'})

    def test_rebuild_replaces_tracked_collection(self):
        self.assertEqual(self.build(), {'FINISHED'})
        previous = self.registry.get('AVV_Generated')
        old_point = previous.all_objects[0]
        self.assertEqual(self.build(), {'FINISHED'})
        replacement = self.registry.get('AVV_Generated')
        self.assertIsNot(replacement, previous)
        self.assertIs(self.scene.geolod_edit_generated_collection, replacement)
        self.assertNotIn(previous, self.registry.entries)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'FINISHED'})
        point = replacement.all_objects[0]
        approx(point.matrix_world.translation, (self.base.origin.x+52, self.base.origin.y+203,10))

    def test_clear_before_restore(self):
        self.assertEqual(self.build(), {'FINISHED'})
        self.assertEqual(views.AVV_OT_clear_generated().execute(self.context), {'FINISHED'})
        self.assertIsNone(self.scene.geolod_edit_generated_collection)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'FINISHED'})

    def test_generated_follows_next_edit_session(self):
        self.assertEqual(self.build(), {'FINISHED'})
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'FINISHED'})
        root = self.registry.get('AVV_Generated')
        point = root.all_objects[0]
        self.assertEqual(lod.GEOLOD_OT_EditLODAtOrigin().execute(self.context), {'FINISHED'})
        approx(point.matrix_world.translation, (2, 3, -2))
        self.assertIs(self.scene.geolod_edit_generated_collection, root)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'FINISHED'})
        approx(point.matrix_world.translation, (self.base.origin.x+52,self.base.origin.y+203,10))

    def test_no_double_transform_when_generated_linked_into_lod_collection(self):
        self.assertEqual(self.build(), {'FINISHED'})
        root = self.registry.get('AVV_Generated')
        obj = root.all_objects[0]
        self.base.collection.objects.link(obj)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'CANCELLED'})
        self.assertTrue(self.scene.geolod_edit_active)
        self.base.collection.objects.unlink(obj)
        self.assertEqual(lod.GEOLOD_OT_RestoreEditedLOD().execute(self.context), {'FINISHED'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
