"""Blender-mock validation of Tool 4. Does not claim live Blender 5.2 testing."""
import csv
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _mock_group_lod as m
import _mock_temporal_views as v
from importlib import import_module
pkg = import_module(Path(__file__).resolve().parent.parent.name)
exp, lod = pkg.export_obj, pkg.lod
import bpy


class LinkList(list):
    def link(self, obj):
        if obj not in self:
            self.append(obj)
    def unlink(self, obj):
        self.remove(obj)


class Registry:
    def __init__(self):
        self.entries = []
    def new(self, name):
        col = v.GenCollection(name)
        self.entries.append(col)
        return col
    def get(self, name):
        return next((c for c in self.entries if c.name == name), None)
    def remove(self, col):
        self.entries.remove(col)


class WM:
    avv_obj_status = ''
    def __init__(self):
        self.messages = []
    def progress_begin(self, start, end):
        self.messages.append(('start', end))
    def progress_update(self, index):
        self.messages.append(('step', index))
    def progress_end(self):
        self.messages.append(('end', None))
    def event_timer_add(self, interval, window=None):
        return 'timer'
    def modal_handler_add(self, op):
        self.messages.append(('modal', op))
    def event_timer_remove(self, timer):
        self.messages.append(('timer_done', timer))


def obj(name, park, vid, kind):
    o = m.MockObject(name, (13, 27, 42))
    o._custom.update({'geolod_generated': True, 'VIEW_ID': vid,
                      'source_type': kind})
    if park is not None:
        o._custom['PARK_NAME'] = park
    return o


class BatchOBJTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = m.FullLODTest()
        self.base.setUp()
        self.scene = self.base.scene
        self.ctx = self.base.context
        self.ctx.window_manager = WM()
        self.ctx.window = None
        self.scene.collection = types.SimpleNamespace(children=LinkList())
        self.scene.geolod_edit_generated_collection = None
        self.scene.avv_obj_settings = types.SimpleNamespace(directory=self.temp.name)
        self.reg = Registry()
        patcher = patch.object(bpy.data, 'collections', self.reg)
        patcher.start()
        self.addCleanup(patcher.stop)
        patch_filepath = patch.object(bpy.data, 'filepath', '/project.blend', create=True)
        patch_filepath.start()
        self.addCleanup(patch_filepath.stop)
        self.avv = self.reg.new('AVV_Generated')
        self.avv['source_crs'] = 'EPSG:7854'
        self.avv['lod_source_frame'] = 'RAW_ENH'
        self.a = obj('Point_TorRiv.R', 'Park 10', 'TorRiv.R', 'viewpoint')
        self.b = obj('Frustum_TorRiv.R_1', None, 'TorRiv.R', 'frustum')
        self.c = obj('Viewshed_TorRiv.R_1', 'Park 10', 'TorRiv.R', 'viewshed')
        self.d = obj('Point_MonH.A', 'Montefiore Hill', 'MonH.A', 'viewpoint')
        for o in (self.a, self.b, self.c, self.d):
            self.avv.objects.link(o)
        self.export_calls = []
        def fake_export(**kwargs):
            self.export_calls.append(dict(kwargs))
            target = kwargs['filepath']
            with open(target, 'w', encoding='utf-8') as f:
                f.write('# simulated Blender 5.2 OBJ exporter\n')
                for o in self.reg.get(kwargs['collection']).objects:
                    f.write('o '+o.name+'\n')
            return {'FINISHED'}
        self.fake_export = fake_export
        if not hasattr(bpy.ops,'wm'):
            bpy.ops.wm=types.SimpleNamespace()
        patched = patch.object(bpy.ops.wm, 'obj_export', side_effect=fake_export, create=True)
        patched.start()
        self.addCleanup(patched.stop)

    def test_separate_types_per_location_use_blender_52_obj_api(self):
        first_pos = self.a.matrix_world.translation.copy()
        outcome = exp.AVV_OT_export_obj_batch().execute(self.ctx)
        self.assertEqual(outcome, {'FINISHED'})
        # 3 file types at Park 10; one available type at Montefiore Hill.
        self.assertEqual(len(self.export_calls), 4)
        self.assertEqual(set(self.reg.get('AVV_Generated').all_objects),
                         {self.a, self.b, self.c, self.d})
        self.assertFalse(self.reg.get('AVV_OBJ_EXPORT_WORKING'))
        self.assertEqual(list(self.a.matrix_world.translation), list(first_pos))
        root = Path(self.export_calls[0]['filepath']).parents[2]
        expected = {
            'Park_10/Points/Park_10__TorRiv.R__Points.obj': 'Point_TorRiv.R',
            'Park_10/Viewsheds/Park_10__TorRiv.R__Viewsheds.obj': 'Viewshed_TorRiv.R_1',
            'Park_10/Frustums/Park_10__TorRiv.R__Frustums.obj': 'Frustum_TorRiv.R_1',
            'Montefiore_Hill/Points/Montefiore_Hill__MonH.A__Points.obj': 'Point_MonH.A',
        }
        self.assertEqual({str(Path(c['filepath']).relative_to(root)).replace('\\', '/')
                          for c in self.export_calls}, set(expected))
        for rel, member in expected.items():
            content = (root / rel).read_text()
            self.assertIn('o ' + member, content)
            # Other categories cannot be silently mixed into any OBJ.
            self.assertEqual(content.count('\no '), 1)
        for c in self.export_calls:
            self.assertEqual(c['forward_axis'], 'Y')
            self.assertEqual(c['up_axis'], 'Z')
            self.assertEqual(c['global_scale'], 1)
            self.assertEqual(c['export_selected_objects'], False)
            self.assertTrue(c['collection'].startswith('AVV_OBJ_EXPORT_WORKING'))
            self.assertEqual(c['apply_transform'], True)
        with open(root/'export_index.csv', encoding='utf-8-sig') as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 4)
        self.assertEqual({r['geometry_type'] for r in rows}, {'Points', 'Viewsheds', 'Frustums'})
        self.assertEqual({r['relative_obj_path'] for r in rows}, set(expected))
        self.assertTrue(all(r['objects'] == '1' for r in rows))
        meta = json.loads((root/'export_reference.json').read_text(encoding='utf-8'))
        self.assertEqual(meta['status'], 'complete')
        self.assertEqual(meta['exported_files'], 4)
        self.assertEqual(meta['exported_views'], 2)
        self.assertEqual(meta['exported_by_type'], {'Points': 2, 'Viewsheds': 1, 'Frustums': 1})
        self.assertEqual(meta['obj_axes'], {'forward': '+Y', 'up': '+Z', 'scale': 1.0})
        self.assertEqual(meta['scene_origin']['northing_m'], repr(float(self.scene['geolod_origin_n'])))

    def test_extension_registers_tool4_properties_and_panel(self):
        fake_wm = type('FakeWindowManager', (), {})
        with patch.object(bpy.types, 'WindowManager', fake_wm, create=True), \
             patch.object(bpy.utils, 'register_class') as registered, \
             patch.object(bpy.utils, 'unregister_class') as unregistered:
            exp.register()
            self.assertEqual(registered.call_count, 3)
            self.assertTrue(hasattr(bpy.types.Scene, 'avv_obj_settings'))
            self.assertTrue(hasattr(fake_wm, 'avv_obj_status'))
            exp.unregister()
            self.assertEqual(unregistered.call_count, 3)
            self.assertFalse(hasattr(bpy.types.Scene, 'avv_obj_settings'))
            self.assertFalse(hasattr(fake_wm, 'avv_obj_status'))

    def test_export_never_changes_object_selection(self):
        self.a.select_set(True)
        self.b.select_set(False)
        self.ctx.active_object = self.a
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'FINISHED'})
        self.assertIs(self.ctx.active_object, self.a)
        self.assertTrue(self.a._selected)
        self.assertFalse(self.b._selected)

    def test_export_refuses_unrestored_edit(self):
        self.scene.geolod_edit_active=True
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'CANCELLED'})
        self.assertEqual(self.export_calls,[])
        self.assertEqual(os.listdir(self.temp.name), [])

    def test_export_refuses_objects_not_generated_by_tool(self):
        untracked=obj('Imported LOD mesh', 'Park 10', 'LOD', 'viewpoint')
        untracked._custom['geolod_generated']=False
        self.avv.objects.link(untracked)
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'CANCELLED'})
        self.assertFalse(self.export_calls)

    def test_export_requires_folder(self):
        self.scene.avv_obj_settings.directory=''
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'CANCELLED'})
        self.assertEqual(self.export_calls,[])

    def test_filename_collision_and_untrusted_path_input(self):
        self.avv.objects.link(obj('another view', 'Park 10', 'Tok/A', 'viewpoint'))
        self.avv.objects.link(obj('third view', 'Park 10', 'Tok_A', 'viewpoint'))
        jobs=exp.build_export_groups(self.avv.all_objects)
        files=[(j['folder'].lower(),j['stem'].lower()) for j in jobs]
        self.assertEqual(len(files), len(set(files)))
        self.assertEqual(exp.path_token('..\\../AUX'), '_AUX')
        self.assertEqual(exp.path_token('CON'), '_CON')
        self.assertEqual(exp.path_token('Park 10'), 'Park_10')

    def test_missing_view_id_is_blocked(self):
        self.a._custom.pop('VIEW_ID')
        with self.assertRaisesRegex(ValueError, 'VIEW_ID'):
            exp.export_preflight(self.scene, self.avv)

    def test_old_frustum_park_name_is_inferred(self):
        groups=exp.build_export_groups(self.avv.all_objects)
        job=next(j for j in groups if j['view_id']=='TorRiv.R' and j['kind']=='frustum')
        self.assertEqual(job['park'], 'Park 10')
        self.assertEqual(len(job['objects']), 1)
        self.assertIs(job['objects'][0], self.b)

    def test_ambiguous_park_for_same_view_is_blocked(self):
        self.avv.objects.link(obj('additional', 'Park 11','TorRiv.R','viewshed'))
        with self.assertRaisesRegex(ValueError, 'multiple locations'):
            exp.build_export_groups(self.avv.all_objects)

    def test_unknown_source_type_fails_preflight_instead_of_mixing(self):
        self.avv.objects.link(obj('Unexpected_geometry', 'Park 10', 'TorRiv.R', 'other'))
        with self.assertRaisesRegex(ValueError, 'unknown source_type'):
            exp.export_preflight(self.scene, self.avv)
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'CANCELLED'})
        self.assertEqual(self.export_calls, [])

    def test_multiple_frustums_same_view_go_into_one_frustums_obj(self):
        second = obj('Frustum_TorRiv.R_2', 'Park 10', 'TorRiv.R', 'frustum')
        self.avv.objects.link(second)
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'FINISHED'})
        matches = [Path(c['filepath']) for c in self.export_calls if '/Frustums/' in c['filepath'].replace('\\','/')]
        self.assertEqual(len(matches), 1)
        content = matches[0].read_text()
        self.assertIn('Frustum_TorRiv.R_1', content)
        self.assertIn('Frustum_TorRiv.R_2', content)
        root = matches[0].parents[2]
        with open(root/'export_index.csv', encoding='utf-8-sig') as f:
            rows = list(csv.DictReader(f))
        frustum = next(r for r in rows if r['geometry_type'] == 'Frustums')
        self.assertEqual(frustum['objects'], '2')
        self.assertEqual(frustum['frustums'], '2')

    def test_second_export_run_never_overwrites_first(self):
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'FINISHED'})
        self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'FINISHED'})
        first, second=self.export_calls[0]['filepath'], self.export_calls[4]['filepath']
        self.assertNotEqual(Path(first).parent.parent, Path(second).parent.parent)
        self.assertTrue(Path(first).exists())
        self.assertTrue(Path(second).exists())

    def test_failed_export_retains_only_completed_and_marks_incomplete(self):
        def failing_export(**kwargs):
            if len(self.export_calls) == 1:
                raise RuntimeError('simulated disk failure')
            return self.fake_export(**kwargs)
        with patch.object(bpy.ops.wm,'obj_export',side_effect=failing_export):
            self.assertEqual(exp.AVV_OT_export_obj_batch().execute(self.ctx), {'CANCELLED'})
        folder = next(Path(self.temp.name).iterdir())
        info=json.loads((folder/'export_reference.json').read_text())
        self.assertEqual(info['status'], 'incomplete')
        self.assertEqual(info['exported_views'], 1)
        self.assertEqual(info['exported_files'], 1)
        self.assertEqual(len(self.reg.entries), 1)

    def test_modal_progress_and_cancel(self):
        # Blender 5.2's Event has no `.timer`. Use a slots class that raises
        # AttributeError if production code ever tries to access it again.
        class Event:
            __slots__ = ('type',)
            def __init__(self, event_type):
                self.type = event_type

        self.ctx.window=object()
        op=exp.AVV_OT_export_obj_batch()
        self.assertEqual(op.invoke(self.ctx,None), {'RUNNING_MODAL'})
        self.assertEqual(op.modal(self.ctx, Event('MOUSEMOVE')), {'RUNNING_MODAL'})
        self.assertEqual(len(self.export_calls), 0)
        self.assertEqual(op.modal(self.ctx, Event('TIMER')), {'RUNNING_MODAL'})
        self.assertEqual(len(self.export_calls),1)
        self.assertEqual(op.modal(self.ctx, Event('ESC')), {'CANCELLED'})
        self.assertEqual(len(self.reg.entries),1)
        self.assertFalse(self.reg.get('AVV_OBJ_EXPORT_WORKING'))
        self.assertIn(('timer_done', 'timer'), self.ctx.window_manager.messages)
        self.assertIn(('end', None), self.ctx.window_manager.messages)
        self.assertIn('incomplete', (Path(next(iter(Path(self.temp.name).iterdir()))) / 'export_reference.json').read_text())

    def test_modal_progress_to_completion_without_event_timer_attribute(self):
        class Event:
            __slots__ = ('type',)
            def __init__(self, event_type):
                self.type = event_type

        self.ctx.window = object()
        op = exp.AVV_OT_export_obj_batch()
        self.assertEqual(op.invoke(self.ctx, Event('LEFTMOUSE')), {'RUNNING_MODAL'})
        self.assertEqual(op.modal(self.ctx, Event('TIMER')), {'RUNNING_MODAL'})
        self.assertEqual(len(self.export_calls), 1)
        for _ in range(2):
            self.assertEqual(op.modal(self.ctx, Event('TIMER')), {'RUNNING_MODAL'})
        self.assertEqual(op.modal(self.ctx, Event('TIMER')), {'FINISHED'})
        self.assertEqual(len(self.export_calls), 4)
        self.assertEqual(len(self.reg.entries), 1)
        self.assertFalse(self.reg.get('AVV_OBJ_EXPORT_WORKING'))
        self.assertIn(('timer_done', 'timer'), self.ctx.window_manager.messages)
        self.assertIn(('end', None), self.ctx.window_manager.messages)
        root = next(Path(self.temp.name).iterdir())
        self.assertEqual(json.loads((root/'export_reference.json').read_text())['status'], 'complete')
        self.assertEqual(len(list(root.rglob('*.obj'))), 4)


if __name__ == '__main__':
    unittest.main(verbosity=2)
