# Adelaide GeoLOD & Views/Vistas — Blender 5.x

Version **1.3.2**. Designed for the City of Adelaide city-scale LOD and two Views & Vistas shapefiles, in **GDA2020 / MGA Zone 54 (EPSG:7854)**. No shapefiles, third-party Python packages, or BlenderGIS are bundled or needed for the Views & Vistas generator.

## Installation

1. Save a backup of your `.blend` project, preferably **before moving the LOD**.
2. Disable/uninstall the previous `adelaide_geolod_views_vistas` extension. Install this ZIP through **Edit → Preferences → Get Extensions → Install from Disk** in Blender 5.x.
3. Open **3D Viewport → N sidebar → Adelaide GeoLOD**.
4. If upgrading an already-active temporary edit, **do not re-register**; restore the existing LOD first, or continue the existing edit carefully. The saved Tool 1 scene origin remains intact.

## Workflow

**Tool 1 — Spatial Data:** Select the two **external `.shp`** files: point **Viewpoints** and polygon **Views & Vistas** (their matching `.shx`, `.dbf`, `.prj` sidecars must be in the same locations). On a new `.blend`, click **Set Scene Origin**. This stores the first active viewpoint's EPSG:7854 Easting/Northing, with height 0 m. If your project has a committed origin from earlier versions, it is retained; select the source files here for Tool 3 and do not re-commit.

**Tool 2 — Edit LOD:** Import your complete city LOD. Select **one building mesh** in the 3D Viewport or Outliner. Click **Register Selected Building**. The add-on chooses the non-generated collection associated with that building and registers **all of its objects**, rather than just the selected mesh; review the short object-count status. Then click **Move LOD to Origin**. The anchor is **the world-space bounding-box centre of the selected building's visible mesh**, not its Blender object origin. Edit the LOD near `(0,0,0)`. Newly created independent LOD objects must be added to the registered LOD collection (the **Include New Objects** button does this for selected objects).

**Tool 3 — Views & Vistas:** While the LOD is temporarily at the origin, click **Build Views & Vistas**. Tool 3 reads the two shapefiles selected in Tool 1; builds viewpoints, viewsheds and frustums into the separate `AVV_Generated` collection; and automatically associates it with the active Tool 2 restoration. No hidden coordinate mode has to be chosen. When ready, return to Tool 2 and click **Restore LOD & Views**. The exact inverse group translation returns all LOD and generated objects to their imported coordinate frame while retaining edits. Subsequent temporary editing sessions move the associated Views & Vistas geometry with the LOD.

## Tool 4 — Batch OBJ export (separated by geometry type in v1.3.2)

After **Restore LOD & Views** in Tool 2, open **4. Export OBJ**. Browse to an
**existing export parent folder** and click **Export Views & Vistas**.

- The add-on creates a **new** `Views_Vistas_Export_YYYYMMDD_HHMMSS` directory
  inside the selected folder; existing exports are never overwritten.
- Each location folder contains separate **Points**, **Viewsheds**, and
  **Frustums** subfolders. Within each type folder there is **one OBJ per
  `VIEW_ID`**, containing only that geometry type's objects. For instance,
  all five frustum meshes for one viewpoint remain in one Frustums OBJ.
- Folders are named from `PARK_NAME` (for example `Park_10`) and filenames
  combine the location, `VIEW_ID`, and geometry type
  (`Park_10__TorRiv.R__Frustums.obj`). Missing park names use other objects
  with the same ID, or `Unspecified_Location`. Absent categories are skipped;
  no empty OBJ files are written. The city LOD buildings are never exported.
- File and folder names are sanitised for Windows and collision-proofed.
- Blender's native **`bpy.ops.wm.obj_export`** is used with fixed settings:
  **Forward +Y, Up +Z, scale 1, Apply Transforms on, Apply Modifiers on**,
  UVs/normals/materials enabled. OBJ/MTL files use Blender's current evaluated
  meshes. There are no axis-setting dropdowns.
- The export runs **one category-specific OBJ at a time** with a UI progress
  update; a large OBJ can still make Blender temporarily busy during its export.
  Press **Esc between files** to cancel. Completed files are preserved.
- Each run includes `export_index.csv` (location, `VIEW_ID`, geometry type,
  relative OBJ path and counts) and `export_reference.json` (source coordinate
  frame, scene origin, axis, CRS and per-type output counts; incomplete runs).
- The add-on temporarily links objects to an export-only collection, which it
  removes afterwards. It does **not** move objects, change scene selection,
  recenter meshes or alter the original `AVV_Generated`/LOD collections.

**Export only after restoring Tool 2.** OBJ files contain model coordinates,
not an embedded GIS coordinate system. `export_reference.json` records how
those coordinates relate to the scene origin. The output will use the **same
imported LOD coordinate frame** used when generating/restoring the geometry;
this is not an independent proof of georeferencing accuracy.

### Example export structure

```text
Views_Vistas_Export_20261014_104000/
  Park_10/
    Points/
      Park_10__TorRiv.R__Points.obj
    Viewsheds/
      Park_10__TorRiv.R__Viewsheds.obj
    Frustums/
      Park_10__TorRiv.R__Frustums.obj
      Park_10__TorRiv.Q__Frustums.obj
  Montefiore_Hill/
    Points/
      Montefiore_Hill__MonH.A__Points.obj
  export_index.csv
  export_reference.json
```

OBJ material files (`.mtl`) are written beside corresponding OBJ files when
Blender exports materials. Folders are created only for categories that have
mesh objects. In ArcGIS Pro **Import 3D Files**, import each geometry type
separately if you want distinct multipatch layers; continue to apply the
coordinate system you have confirmed works with your previous OBJ export.

**No regeneration required:** Existing `AVV_Generated` objects created by
v1.2.x/v1.3.x can be exported with the new layout as long as each has its
original `VIEW_ID` and `source_type` properties and Tool 2 is restored.
Unknown source types are rejected rather than silently mixed into a file.

## Minimal UI

Only the two file selectors in Tool 1, action buttons in Tools 2–3, and the export-folder picker and button in Tool 4 are shown. Alignment modes, anchor choices, VIEW_ID filters, metadata readouts and styling defaults are not displayed. All data features are built; colours, dimensions and heights use internal defaults. No metadata text labels are created. Machine-readable source attributes remain on generated Blender objects for provenance, but do not appear as UI labels.

## Safeguards and limitations

- **This is not an automatic georeferencer for unknown LOD data.** Tool 2 preserves the LOD's imported coordinates. Tool 3 detects whether those original positions look like raw EPSG:7854 MGA coordinates or Tool 1 scene-local values. If neither interpretation is plausibly near the viewpoint shapefile, building is refused. This is a *coarse placement safeguard*, **not** a surveyed alignment check.
- **Confirm source CRS, LOD scale, orientation, horizontal offset, and vertical datum.** Vertical height matching cannot be inferred. An unreferenced or incorrectly georeferenced LOD needs a separately validated control-point transformation before Views & Vistas can be geographically accurate.
- Tool 1 `.prj` WKT verification is required and no reprojection is performed. Z is in metres and derived primarily from `ALTITUDE_1`; default values may be applied when records lack elevation.
- Ensure the **whole LOD** is inside the registered collection, and exclude cameras, unrelated content and generated AVV objects. Do not move or unlink registered objects outside the workflow during an active edit.
- Do not rename or manually merge the generated collection while a temporary edit is active. Generated objects stay under `AVV_Generated`, not the LOD collection, to prevent double movement. Rebuilding uses a staging-and-replacement flow.
- A completed LOD restore does **not** mean that geographic alignment is verified. Avoid using the result for authoritative planning analyses until checked against known survey points.
- This add-on has been syntax-checked and regression-tested with **mock Blender objects**, including a full 8,200-object round trip. **Interactive Blender 5.x testing with the real city LOD has not been performed here.**

## Internal tests

After extracting the extension to a folder with package name `adelaide_geolod_views_vistas`:

```bash
python qa/test_streamlined_adelaide.py
```

The test suite uses mock Blender internals; it does not require a Blender installation. It covers scene-origin setup, reference selection, 8,200 objects, source-frame detection, generated geometry restoration, rebuilding, and hidden controls.

## v1.2.1 fix

The Tool 2 **Register Selected Building** action no longer tries to instantiate Blender operators from Python. It uses ordinary shared registration functions, avoiding the `bpy_struct.__new__` `TypeError` in Blender 5.2. Existing saved Tool 1 origins and shapefile paths are unchanged. If the registration previously failed with this traceback, select a building and try again; no LOD movement took place.

## v1.3.0 technical validation

Run `python qa/test_batch_obj_export.py` after extracting the ZIP into the
`adelaide_geolod_views_vistas` package. Tests cover location grouping,
Blender 5.2 export operator arguments, parent-folder creation, non-overwrite,
partial export failure, modal progress/cancellation, coordinate-reference
sidecars, and preservation of Blender object positions. The original workflow
regression suite remains included. **Live Blender 5.2 export has not been
executed in this environment.**

## v1.3.1 — Blender modal-event compatibility fix

- Fixed Tool 4's modal timer handler. Blender 5.2 events have no `event.timer` property, which caused an `AttributeError` on the first export tick in v1.3.0.
- Tool 4 now processes `TIMER` events without accessing unsupported properties. It retains per-view progress, Esc cancellation, cleanup, partial-run records, and OBJ settings unchanged.
- Restart Blender after uninstalling v1.3.0 to clear any temporary `AVV_OBJ_EXPORT_WORKING` collection or orphaned timer left by the failed handler. Existing generated Views & Vistas models are unaffected.
- The test suite includes modal events intentionally lacking a `timer` attribute, the specific scenario behind the traceback.
- Tests are Python mocks; Blender 5.2 live export remains unverified.

## v1.3.2 — Separate Points, Viewsheds and Frustums OBJ files

- Added fixed category subfolders inside each location: `Points`, `Viewsheds`,
  `Frustums`, with separate per-`VIEW_ID` OBJ and optional MTL files.
- Preserved the exact Blender OBJ axes (+Y forward, +Z up), scale, transforms,
  georeference reference file and non-destructive export workflow from v1.3.1.
- Expanded CSV index with a `geometry_type` column and JSON with exported-file
  counts per type; incomplete exports retain only completed files in the index.
- Tool 4 retains the minimal folder picker and single export button. Tools 1–3
  are unchanged. Blender interactive testing of this revision is outstanding.
