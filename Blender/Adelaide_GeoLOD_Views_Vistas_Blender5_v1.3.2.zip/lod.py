"""Collection-wide, anchor-based LOD georeferencing and reversible editing.

All transformations are TRANSLATIONS of the scene's LOD collection roots.
Restoration reverses the offset rather than forcing old object positions,
so geometry edits, moved objects and added collection members follow back.
"""
import math
from collections import defaultdict

import bpy
from bpy.props import BoolProperty, CollectionProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Vector

from .georef import anchor, has_anchor, parse_xyz


class GEOLOD_PG_RegisteredLOD(PropertyGroup):
    object_ref: PointerProperty(name='LOD Object', type=bpy.types.Object)
    initial_world_pos: StringProperty(name='Legacy original XYZ', options={'HIDDEN'})


class GEOLOD_PG_TemporaryPosition(PropertyGroup):
    object_ref: PointerProperty(name='Legacy edited LOD object', type=bpy.types.Object)
    original_world_pos: StringProperty(name='Legacy pre-edit XYZ', options={'HIDDEN'})


def serialize_vec(vec):
    return '|'.join(repr(float(n)) for n in vec)


def deserialize_vec(text):
    values = str(text).split('|')
    if len(values) != 3:
        raise ValueError('Saved translation must contain three coordinates')
    return Vector([parse_xyz(v, 'Saved translation coordinate') for v in values])


def registered(scene):
    return {r.object_ref for r in scene.geolod_registered_lod if r.object_ref}


def edit_active(scene):
    return bool(scene.geolod_edit_active or scene.geolod_edit_positions)


def active_collection(scene):
    return scene.geolod_registered_collection if scene.geolod_registration_active else None


def active_generated_members(scene):
    """Views & Vistas generated during this edit remain a separate collection.

    They are nevertheless translated alongside the LOD on restoration. Only
    the exact collection explicitly bound to this scene's edit is included.
    """
    col = getattr(scene, 'geolod_edit_generated_collection', None)
    if col is None:
        return set()
    if col.name != 'AVV_Generated':
        raise ValueError('Attached Views & Vistas collection was replaced or renamed; check collection before restoring')
    return set(col.all_objects) & set(scene.objects)


def group_for_edit_restore(scene, lod_group):
    views_group = active_generated_members(scene)
    if views_group & lod_group:
        raise ValueError('Views & Vistas are linked into the LOD collection. Keep generated objects in their own AVV_Generated collection')
    # An unrelated child of an object in the translation group would move too.
    all_group = lod_group | views_group
    outsiders = [o.name for o in scene.objects if o not in all_group and any_parent_selected(o, all_group)]
    if outsiders:
        raise ValueError('LOD/Views parent has children outside the restoration scope: ' + ', '.join(outsiders[:3]))
    return all_group


def geolod_edit_delta(scene):
    if not scene.geolod_edit_active:
        raise ValueError('No current collection-wide LOD edit session')
    return deserialize_vec(scene.geolod_edit_delta)


def group_members(scene, collection):
    if collection is None:
        raise ValueError('Choose a collection containing the complete LOD model')
    scene_objs = set(scene.objects)
    group = set(collection.all_objects) & scene_objs
    if not group:
        raise ValueError('The chosen LOD collection contains no scene objects')
    return group


def is_generated(obj):
    return bool(obj.get('geolod_generated')) or any(c.name.startswith('AVV_') for c in obj.users_collection)


def validate_group(scene, group):
    if any(is_generated(o) for o in group):
        raise ValueError('LOD collection contains generated Views & Vistas objects')
    # Parenting can move descendants even if they are not members of the chosen collection.
    # Refuse a partially included hierarchy instead of silently moving other scene content.
    outsiders = [obj.name for obj in scene.objects
                if obj not in group and any_parent_selected(obj, group)]
    if outsiders:
        raise ValueError('LOD parents have children outside LOD collection: ' + ', '.join(outsiders[:3]) + '. Add them to the LOD collection first')


def any_parent_selected(obj, chosen):
    p = obj.parent
    while p:
        if p in chosen:
            return True
        p = p.parent
    return False


def root_objects(chosen):
    return sorted((o for o in chosen if not any_parent_selected(o, chosen)), key=lambda o: o.name)


def depth(obj):
    n = 0
    while obj.parent:
        n += 1
        obj = obj.parent
    return n


def check_editable(objects):
    blocked = [o.name for o in objects if not o.is_editable or o.library is not None]
    if blocked:
        raise ValueError('Linked/read-only LOD objects: ' + ', '.join(blocked[:3]))
    constrained = [o.name for o in objects if any(not c.mute and c.influence > 0 for c in o.constraints)]
    if constrained:
        raise ValueError('Active constraints require baking first: ' + ', '.join(constrained[:3]))
    driven = [o.name for o in objects if o.animation_data and (o.animation_data.action or o.animation_data.drivers)]
    if driven:
        raise ValueError('Animated/driven transforms require baking first: ' + ', '.join(driven[:3]))


def restore_world_positions(context, positions):
    """Only for rollback/legacy restoration; NOT normal reverse-edit translation."""
    grouped = defaultdict(list)
    for obj, vec in positions.items():
        grouped[depth(obj)].append((obj, vec))
    for d in sorted(grouped):
        for obj, position in grouped[d]:
            world = obj.matrix_world.copy()
            world.translation = position
            obj.matrix_world = world
        context.view_layer.update()


def translate_group(context, group, delta):
    """Atomic best-effort rollback for a group of roots; children follow once."""
    roots = root_objects(group)
    original = {o: o.matrix_world.copy() for o in roots}
    try:
        for obj in roots:
            matrix = obj.matrix_world.copy()
            matrix.translation = matrix.translation + delta
            obj.matrix_world = matrix
        context.view_layer.update()
    except Exception:
        for obj in roots:
            try:
                obj.matrix_world = original[obj]
            except Exception:
                pass
        context.view_layer.update()
        raise


def validate_registered_scope(scene, group):
    lost = registered(scene) - group
    if lost:
        raise ValueError('Registered LOD object(s) left the LOD collection: ' + ', '.join(sorted(o.name for o in lost)[:3]) + '. Relink before restoring')


def legacy_active(scene):
    return bool(scene.geolod_registered_lod and not scene.geolod_registration_active)


def get_bounds_centre(group):
    left = right = bottom = top = None
    for obj in group:
        points = ((obj.matrix_world @ Vector(p)) for p in obj.bound_box) if obj.type == 'MESH' and len(obj.data.vertices) else (obj.matrix_world.translation,)
        for p in points:
            x, y = float(p.x), float(p.y)
            left = x if left is None else min(left, x)
            right = x if right is None else max(right, x)
            bottom = y if bottom is None else min(bottom, y)
            top = y if top is None else max(top, y)
    return ((left + right) / 2, (bottom + top) / 2) if left is not None else None


def mesh_bounds_centre(obj):
    """Centre of visible reference mesh bounding box in world coordinates.

    Blender mesh vertices can contain remote world positions even when the
    Object's transform is zero (common in large imported city LOD datasets).
    Moving only by matrix_world.translation would then be a no-op.
    """
    if obj.type != 'MESH' or obj.data is None or len(obj.data.vertices) == 0:
        raise ValueError('Reference has no mesh vertices; choose a mesh building or use Object Origin / 3D Cursor anchor')
    corners = obj.bound_box
    if len(corners) != 8:
        raise ValueError('Reference mesh bounding box is unavailable; use Object Origin or 3D Cursor anchor')
    world = [obj.matrix_world @ Vector(co) for co in corners]
    for p in world:
        if not all(math.isfinite(float(v)) for v in p):
            raise ValueError('Reference mesh has invalid world-space bounds')
    return Vector(tuple((min(float(p[i]) for p in world) + max(float(p[i]) for p in world)) / 2.0 for i in range(3)))


def edit_anchor(scene, ref, settings):
    """Choose the edit anchor independent of the reference object's origin."""
    mode = settings.lod_edit_anchor
    if mode == 'GEOMETRY':
        return mesh_bounds_centre(ref)
    if mode == 'ORIGIN':
        return ref.matrix_world.translation.copy()
    if mode == 'CURSOR':
        return scene.cursor.location.copy()
    raise ValueError('Unsupported edit anchor type: ' + str(mode))


def format_coords(v):
    return f'{v.x:.3f}, {v.y:.3f}, {v.z:.3f}'


def prepare_reference_from_selection(context):
    """Set the Adelaide reference/collection from the active LOD object.

    Shared by the legacy reference operator and the one-click workflow.
    No Blender operator instances are constructed.
    """
    obj = context.active_object
    if obj is None and len(context.selected_objects) == 1:
        obj = context.selected_objects[0]
    if not obj or is_generated(obj):
        raise ValueError('Select one LOD building mesh as the active object')
    scene = context.scene
    eligible = [c for c in obj.users_collection
                if c.name != 'AVV_Generated' and not c.name.startswith('AVV_')]
    eligible = [c for c in eligible
                if not any(is_generated(item) for item in c.all_objects)]
    if not eligible:
        raise ValueError('Cannot find a LOD collection for the selected building')
    best = max(eligible, key=lambda col: len(col.all_objects))
    scene.geolod_settings.reference_object = obj
    scene.geolod_settings.lod_collection = best
    scene.geolod_settings.lod_edit_anchor = 'GEOMETRY'
    scene.geolod_settings.lod_mode = 'EDIT_ONLY'
    return best


class GEOLOD_OT_UseActiveReference(Operator):
    bl_idname = 'geolod.use_active_reference'
    bl_label = 'Use Active as Reference'
    bl_description = 'Use the selected building to find its complete LOD collection'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            collection = prepare_reference_from_selection(context)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc)); return {'CANCELLED'}
        self.report({'INFO'}, f'LOD collection ready: {collection.name} ({len(collection.all_objects)} objects)')
        return {'FINISHED'}


def register_lod_collection(context, report):
    """Perform registration from ordinary Python, reporting via caller.

    A Blender bpy.types.Operator instance must not be created with
    GEOLOD_OT_RegisterLOD() from another operator's execute() method.
    """
    scene = context.scene
    ss = scene.geolod_settings
    if not has_anchor(scene):
        report({'ERROR'}, 'Set the scene origin in Tool 1 first')
        return {'CANCELLED'}
    if edit_active(scene) or scene.geolod_registration_active or scene.geolod_registered_lod:
        report({'ERROR'}, 'A LOD registration or temporary edit already exists; do not double-register')
        return {'CANCELLED'}
    reference = ss.reference_object
    try:
        group = group_members(scene, ss.lod_collection)
        validate_group(scene, group)
        if reference not in group:
            raise ValueError('Choose a reference object inside the LOD collection')
        check_editable(group)
        mode = 'EDIT_ONLY'  # Adelaide preset: preserve imported LOD coordinates
        if mode == 'EDIT_ONLY' or mode == 'LOCAL':
            # Explicitly preserve imported placement. LOCAL is a user assertion
            # of scene-local alignment; EDIT_ONLY makes NO spatial assertion.
            delta = Vector((0.0, 0.0, 0.0))
        else:
            ox, oy, oz = anchor(scene)
            if mode == 'PROJECTED':
                bounds = get_bounds_centre(group)
                if not bounds or math.hypot(bounds[0] - ox, bounds[1] - oy) > 300000:
                    raise ValueError('LOD is not near scene EPSG:7854 origin. Is it already local or in another CRS? Choose Preserve Imported Position for edit-only operation')
                delta = Vector((-ox, -oy, -oz))
            elif mode == 'CONTROL':
                if not str(ss.control_easting).strip() or not str(ss.control_northing).strip():
                    raise ValueError('Enter surveyed EPSG:7854 Control Easting and Northing (numeric metres); snapping cursor alone does not populate these fields')
                cx = parse_xyz(ss.control_easting, 'Control easting')
                cy = parse_xyz(ss.control_northing, 'Control northing')
                cz = parse_xyz(ss.control_height, 'Control height')
                if math.hypot(cx - ox, cy - oy) > 300000:
                    raise ValueError('Surveyed control point is too far from scene origin')
                cursor = scene.cursor.location
                delta = Vector((cx - ox - cursor.x, cy - oy - cursor.y, cz - oz - cursor.z))
            else:
                raise ValueError('Unsupported LOD alignment mode: ' + str(mode))
    except (ValueError, OverflowError) as exc:
        report({'ERROR'}, str(exc)[:220]); return {'CANCELLED'}
    try:
        # A zero registration delta must not perturb the original matrices.
        if delta.length_squared > 0:
            translate_group(context, group, delta)
        scene.geolod_registered_collection = ss.lod_collection
        scene.geolod_reference_object = reference
        scene.geolod_registration_delta = serialize_vec(delta)
        scene.geolod_registration_mode = mode
        scene.geolod_registration_active = True
        for o in sorted(group, key=lambda x: x.name):
            row = scene.geolod_registered_lod.add()
            row.object_ref = o
    except Exception as exc:
        # Translation is already atomic. On metadata failure, undo the movement.
        try:
            if delta.length_squared > 0:
                translate_group(context, group, -delta)
        except Exception:
            report({'ERROR'}, 'Registration failed and rollback failed; use Blender Undo')
            return {'CANCELLED'}
        scene.geolod_registered_lod.clear()
        scene.geolod_registration_active = False
        scene.geolod_registration_mode = ''
        scene.geolod_registered_collection = None
        scene.geolod_reference_object = None
        report({'ERROR'}, 'Registration failed: ' + str(exc)[:140]); return {'CANCELLED'}
    if mode == 'EDIT_ONLY':
        report({'INFO'}, f'Prepared {len(group)} LOD objects for reversible editing. Imported coordinates UNCHANGED; georeferencing NOT established')
    else:
        report({'INFO'}, f'Prepared {len(group)} LOD objects ({mode}), anchor {reference.name}. Use Move Entire LOD to Edit Origin to edit')
    return {'FINISHED'}


class GEOLOD_OT_RegisterLOD(Operator):
    bl_idname = 'geolod.register_lod'
    bl_label = 'Register Entire LOD'
    bl_description = 'Prepare the complete LOD collection for reversible editing'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return register_lod_collection(context, self.report)


class GEOLOD_OT_RegisterSelectedLOD(Operator):
    bl_idname = 'geolod.register_selected_lod'
    bl_label = 'Register Selected Building'
    bl_description = 'Register the entire LOD collection from one active building'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if scene.geolod_registration_active or edit_active(scene) or scene.geolod_registered_lod:
            self.report({'ERROR'}, 'LOD already registered or editing is active; restore or clear registration first')
            return {'CANCELLED'}
        if not has_anchor(scene):
            self.report({'ERROR'}, 'Set the scene origin in Tool 1 first')
            return {'CANCELLED'}
        try:
            prepare_reference_from_selection(context)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc)); return {'CANCELLED'}
        return register_lod_collection(context, self.report)


class GEOLOD_OT_EditLODAtOrigin(Operator):
    bl_idname = 'geolod.edit_lod_origin'
    bl_label = 'Move Entire LOD to Edit Origin'
    bl_description = 'Move the whole registered collection so the chosen reference anchor (mesh centre, origin, or cursor) reaches (0,0,0)'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if edit_active(scene):
            self.report({'ERROR'}, 'Temporary LOD edit already active. Restore it first'); return {'CANCELLED'}
        if not scene.geolod_registration_active:
            self.report({'ERROR'}, 'Register the entire LOD with this version first'); return {'CANCELLED'}
        try:
            # A pointer to a generated collection from a previous interrupted
            # session must never result in an unexpected extra translation.
            scene.geolod_edit_generated_collection = None
            group = group_members(scene, active_collection(scene))
            validate_group(scene, group)
            validate_registered_scope(scene, group)
            ref = scene.geolod_reference_object
            if ref not in group:
                raise ValueError('Reference object is missing from registered LOD collection')
            check_editable(group)
            scene.geolod_settings.lod_edit_anchor = 'GEOMETRY'
            anchor_pos = mesh_bounds_centre(ref)
            delta = -anchor_pos
            if delta.length_squared < 1e-12:
                raise ValueError('Chosen edit anchor is at (0,0,0). Choose Geometry Centre for models with zero object origins, or select a different reference building')
            # Previously generated geometry bound to this LOD follows the
            # same translation on subsequent edit sessions.
            previous_views = bpy.data.collections.get('AVV_Generated')
            follow_views = bool(previous_views and previous_views.get('geolod_attached_to_lod'))
            if follow_views:
                scene.geolod_edit_generated_collection = previous_views
            full_group = group_for_edit_restore(scene, group)
            check_editable(full_group)
            translate_group(context, full_group, delta)
            scene.geolod_edit_delta = serialize_vec(delta)
            scene.geolod_edit_anchor_used = scene.geolod_settings.lod_edit_anchor
            scene.geolod_edit_active = True
        except Exception as exc:
            self.report({'ERROR'}, str(exc)[:210]); return {'CANCELLED'}
        self.report({'INFO'}, f'Moved {len(group)} LOD objects using {scene.geolod_edit_anchor_used} anchor on {ref.name}. Add new objects to the LOD collection; restore when finished')
        return {'FINISHED'}


class GEOLOD_OT_AddSelectedToLOD(Operator):
    bl_idname = 'geolod.add_selected_to_lod'
    bl_label = 'Include Selected New Objects in LOD'
    bl_description = 'Link newly created objects into the LOD collection so they follow the restoration offset'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not scene.geolod_registration_active or not scene.geolod_edit_active:
            self.report({'ERROR'}, 'Only available while editing the complete registered LOD at origin'); return {'CANCELLED'}
        col = active_collection(scene)
        chosen = set(context.selected_objects)
        if not chosen:
            self.report({'ERROR'}, 'Select new LOD objects to include'); return {'CANCELLED'}
        if any(is_generated(o) for o in chosen):
            self.report({'ERROR'}, 'Cannot include generated Views & Vistas geometry'); return {'CANCELLED'}
        added = []
        try:
            check_editable(chosen)
            for obj in chosen:
                if obj not in col.all_objects:
                    col.objects.link(obj)
                    added.append(obj)
            validate_group(scene, group_members(scene, col))
        except Exception as exc:
            for obj in reversed(added):
                try:
                    col.objects.unlink(obj)
                except Exception:
                    pass
            self.report({'ERROR'}, 'Could not include selected objects: ' + str(exc)[:155]); return {'CANCELLED'}
        self.report({'INFO'}, f'Added {len(added)} object(s). They will follow the LOD when restored')
        return {'FINISHED'}


class GEOLOD_OT_RestoreEditedLOD(Operator):
    bl_idname = 'geolod.restore_edited_lod'
    bl_label = 'Restore Entire LOD Georeferenced'
    bl_description = 'Reverse the saved group-wide offset, preserving editing changes and new objects in collection'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode before restoring the entire LOD and generated Views & Vistas')
            return {'CANCELLED'}
        scene = context.scene
        if scene.geolod_edit_active:
            moved = False
            before_count = len(scene.geolod_registered_lod)
            try:
                group = group_members(scene, active_collection(scene))
                validate_group(scene, group)
                validate_registered_scope(scene, group)
                full_group = group_for_edit_restore(scene, group)
                check_editable(full_group)
                delta = deserialize_vec(scene.geolod_edit_delta)
                translate_group(context, full_group, -delta)
                moved = True
                tracked = registered(scene)
                for o in sorted(group - tracked, key=lambda x: x.name):
                    row = scene.geolod_registered_lod.add()
                    row.object_ref = o
                scene.geolod_edit_delta = ''
                scene.geolod_edit_anchor_used = ''
                scene.geolod_edit_active = False
                scene.geolod_edit_generated_collection = None
            except Exception as exc:
                if moved:
                    try:
                        translate_group(context, full_group, delta)
                    except Exception:
                        self.report({'ERROR'}, 'Restore and rollback both failed; use Blender Undo')
                        return {'CANCELLED'}
                while len(scene.geolod_registered_lod) > before_count:
                    scene.geolod_registered_lod.remove(len(scene.geolod_registered_lod)-1)
                self.report({'ERROR'}, 'Restore not completed: ' + str(exc)[:170]); return {'CANCELLED'}
            suffix = 'to imported placement' if scene.geolod_registration_mode == 'EDIT_ONLY' else 'to registered placement'
            view_count = len(full_group) - len(group)
            self.report({'INFO'}, f'Restored {len(group)} LOD and {view_count} Views & Vistas objects {suffix}; edits retained')
            return {'FINISHED'}
        # v1.0.2 legacy temporary position data: retained to let existing .blend users restore.
        rows = scene.geolod_edit_positions
        if not rows:
            self.report({'WARNING'}, 'No temporary edit is active'); return {'CANCELLED'}
        try:
            targets = {r.object_ref: deserialize_vec(r.original_world_pos) for r in rows if r.object_ref}
            check_editable(targets)
            restore_world_positions(context, targets)
            rows.clear()
        except Exception as exc:
            self.report({'ERROR'}, 'Legacy restore failed: ' + str(exc)[:160]); return {'CANCELLED'}
        self.report({'INFO'}, 'Restored legacy v1.0.2 positions. Re-register to use the new group workflow')
        return {'FINISHED'}


class GEOLOD_OT_UnregisterLOD(Operator):
    bl_idname = 'geolod.unregister_lod'
    bl_label = 'Unregister Entire LOD'
    bl_description = 'Remove geospatial registration and reverse the registration offset (not edit positions)'
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        if edit_active(scene):
            self.report({'ERROR'}, 'Restore LOD edit-at-origin before unregistering'); return {'CANCELLED'}
        if bpy.data.collections.get('AVV_Generated') is not None:
            self.report({'ERROR'}, 'Clear Views & Vistas generated geometry before unregistering'); return {'CANCELLED'}
        if scene.geolod_registration_active:
            try:
                group = group_members(scene, active_collection(scene))
                validate_group(scene, group)
                validate_registered_scope(scene, group)
                check_editable(group)
                delta = deserialize_vec(scene.geolod_registration_delta)
                if delta.length_squared > 0:
                    translate_group(context, group, -delta)
            except Exception as exc:
                self.report({'ERROR'}, 'Unregister failed: ' + str(exc)[:180]); return {'CANCELLED'}
            scene.geolod_registration_active = False
            scene.geolod_registration_mode = ''
            scene.geolod_registered_collection = None
            scene.geolod_reference_object = None
            scene.geolod_registration_delta = ''
            scene.geolod_registered_lod.clear()
            self.report({'INFO'}, f'Unregistered {len(group)} LOD objects; edits preserved')
            return {'FINISHED'}
        if legacy_active(scene):
            try:
                targets = {r.object_ref: deserialize_vec(r.initial_world_pos) for r in scene.geolod_registered_lod if r.object_ref}
                check_editable(targets)
                restore_world_positions(context, targets)
            except Exception as exc:
                self.report({'ERROR'}, 'Legacy unregister failed: ' + str(exc)[:160]); return {'CANCELLED'}
            scene.geolod_registered_lod.clear()
            self.report({'INFO'}, 'Legacy v1.0.2 LOD unregistered. You may now use the complete-collection workflow')
            return {'FINISHED'}
        self.report({'WARNING'}, 'No LOD registration exists'); return {'CANCELLED'}


class GEOLOD_OT_SelectRegisteredLOD(Operator):
    bl_idname = 'geolod.select_registered_lod'
    bl_label = 'Select Entire Registered LOD'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode'); return {'CANCELLED'}
        scene = context.scene
        group = group_members(scene, active_collection(scene)) if scene.geolod_registration_active else registered(scene)
        bpy.ops.object.select_all(action='DESELECT')
        count = 0
        for obj in group:
            try:
                obj.select_set(True)
                count += 1
            except RuntimeError:
                pass
        self.report({'INFO'}, f'Selected {count} LOD objects'); return {'FINISHED'}


class GEOLOD_PT_LOD(Panel):
    bl_label = '2. Edit LOD'
    bl_idname = 'GEOLOD_PT_register_lod'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Adelaide GeoLOD'
    bl_order = 2

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        if legacy_active(scene):
            layout.label(text='Restore earlier edit first', icon='ERROR')
            layout.operator('geolod.restore_edited_lod', text='Restore Previous Edit')
            return
        if scene.geolod_edit_active:
            layout.label(text='Editing near origin', icon='CHECKMARK')
            layout.operator('geolod.add_selected_to_lod', text='Include New Objects', icon='ADD')
            layout.operator('geolod.restore_edited_lod', text='Restore LOD & Views', icon='LOOP_BACK')
        elif scene.geolod_registration_active:
            if scene.geolod_registered_collection:
                layout.label(text=f'{len(scene.geolod_registered_collection.all_objects):,} objects ready', icon='CHECKMARK')
            layout.operator('geolod.edit_lod_origin', text='Move LOD to Origin', icon='PIVOT_CURSOR')
            layout.operator('geolod.unregister_lod', text='Clear Registration', icon='X')
        else:
            row = layout.row()
            row.enabled = has_anchor(scene)
            row.operator('geolod.register_selected_lod', text='Register Selected Building', icon='CHECKMARK')


CLASSES = (GEOLOD_PG_RegisteredLOD, GEOLOD_PG_TemporaryPosition,
           GEOLOD_OT_UseActiveReference, GEOLOD_OT_RegisterLOD,
           GEOLOD_OT_RegisterSelectedLOD,
           GEOLOD_OT_EditLODAtOrigin, GEOLOD_OT_AddSelectedToLOD,
           GEOLOD_OT_RestoreEditedLOD, GEOLOD_OT_UnregisterLOD,
           GEOLOD_OT_SelectRegisteredLOD, GEOLOD_PT_LOD)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.geolod_registered_lod = CollectionProperty(type=GEOLOD_PG_RegisteredLOD)
    bpy.types.Scene.geolod_edit_positions = CollectionProperty(type=GEOLOD_PG_TemporaryPosition)  # legacy project recovery
    bpy.types.Scene.geolod_registered_collection = PointerProperty(type=bpy.types.Collection)
    bpy.types.Scene.geolod_reference_object = PointerProperty(type=bpy.types.Object)
    bpy.types.Scene.geolod_registration_delta = StringProperty(default='', options={'HIDDEN'})
    bpy.types.Scene.geolod_registration_mode = StringProperty(default='', options={'HIDDEN'})
    bpy.types.Scene.geolod_registration_active = BoolProperty(default=False, options={'HIDDEN'})
    bpy.types.Scene.geolod_edit_delta = StringProperty(default='', options={'HIDDEN'})
    bpy.types.Scene.geolod_edit_anchor_used = StringProperty(default='', options={'HIDDEN'})
    bpy.types.Scene.geolod_edit_active = BoolProperty(default=False, options={'HIDDEN'})
    bpy.types.Scene.geolod_edit_generated_collection = PointerProperty(type=bpy.types.Collection)


def unregister():
    for prop in ('geolod_edit_generated_collection', 'geolod_edit_active', 'geolod_edit_anchor_used', 'geolod_edit_delta', 'geolod_registration_active',
                 'geolod_registration_delta', 'geolod_registration_mode', 'geolod_reference_object',
                 'geolod_registered_collection', 'geolod_edit_positions', 'geolod_registered_lod'):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
