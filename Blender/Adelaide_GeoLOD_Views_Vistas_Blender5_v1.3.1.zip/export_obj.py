"""Tool 4: location-organised OBJ exports for generated Adelaide Views & Vistas.

Exports only the AVV_Generated collection after the temporary edit is restored.
Each VIEW_ID produces one OBJ containing all related viewpoint/viewshed/frustum
mesh objects. No transforms, selections, origins or user collections are changed.
"""

import csv
from datetime import datetime
import hashlib
import json
import os
import re
import unicodedata

import bpy
from bpy.props import PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup

from . import georef, lod


WIN_RESERVED = {'CON', 'PRN', 'AUX', 'NUL'} | {
    f'{prefix}{i}' for prefix in ('COM', 'LPT') for i in range(1, 10)
}
GENERATED_COLLECTION = 'AVV_Generated'


def path_token(value, fallback='Unknown', max_length=54):
    """Portable Windows-safe folder or file component; never trust SHP attribute text as path."""
    normal = unicodedata.normalize('NFKD', str(value or ''))
    ascii_name = normal.encode('ascii', 'ignore').decode('ascii')
    cleaned = re.sub(r'[^A-Za-z0-9._-]+', '_', ascii_name).strip(' ._-')
    cleaned = re.sub(r'_+', '_', cleaned)[:max_length].rstrip(' ._-')
    if not cleaned:
        cleaned = fallback
    if cleaned.split('.')[0].upper() in WIN_RESERVED:
        cleaned = '_' + cleaned
    return cleaned


def build_export_groups(objects):
    """Group generated meshes by authoritative VIEW_ID and PARK_NAME.

    Frustums produced by old releases lack PARK_NAME. Fill it from their
    corresponding point/viewshed. Refuse ambiguous IDs rather than misfile.
    """
    objects = list(objects)
    place_by_id = {}
    for obj in objects:
        view_id = str(obj.get('VIEW_ID') or '').strip()
        park = str(obj.get('PARK_NAME') or '').strip()
        if view_id and park:
            place_by_id.setdefault(view_id, set()).add(park)

    groups = {}
    for obj in objects:
        if obj.type != 'MESH':
            raise ValueError(f'Generated object is not a mesh: {obj.name}')
        view_id = str(obj.get('VIEW_ID') or '').strip()
        if not view_id:
            raise ValueError(f'Generated object lacks VIEW_ID: {obj.name}')
        park = str(obj.get('PARK_NAME') or '').strip()
        if not park:
            parks = place_by_id.get(view_id, set())
            if len(parks) > 1:
                raise ValueError(f'VIEW_ID {view_id} has multiple locations; cannot place {obj.name}')
            park = next(iter(parks), 'Unspecified_Location')
        groups.setdefault((park, view_id), []).append(obj)

    parks = sorted({park for park, _vid in groups}, key=lambda name: (name.casefold(), name))
    folder_names = {}
    used_folders = set()
    for park in parks:
        folder = path_token(park, fallback='Unspecified_Location')
        if folder.casefold() in used_folders:
            suffix = hashlib.sha256(park.encode('utf-8')).hexdigest()[:8]
            folder = f'{folder[:45]}__{suffix}'
        folder_names[park] = folder
        used_folders.add(folder.casefold())

    used = set()
    jobs = []
    for (park, view_id), members in sorted(groups.items(), key=lambda item: (item[0][0].casefold(), item[0][1].casefold())):
        folder = folder_names[park]
        stem = f'{path_token(park)}__{path_token(view_id, fallback="View_ID")}'
        # Windows paths are case-insensitive: avoid collisions after sanitisation.
        key = (folder.casefold(), stem.casefold())
        if key in used:
            suffix = hashlib.sha256(f'{park}\x00{view_id}'.encode('utf-8')).hexdigest()[:8]
            stem = f'{stem[:100]}__{suffix}'
            key = (folder.casefold(), stem.casefold())
        if key in used:
            raise ValueError(f'Cannot create unique file name for {view_id}')
        used.add(key)
        counts = {}
        for obj in members:
            source_type = str(obj.get('source_type') or 'other')
            counts[source_type] = counts.get(source_type, 0) + 1
        jobs.append({'park': park, 'view_id': view_id, 'folder': folder,
                     'stem': stem, 'objects': sorted(members, key=lambda o: o.name),
                     'counts': counts})
    return jobs


def export_preflight(scene, generated):
    if lod.edit_active(scene):
        raise ValueError('Restore LOD & Views in Tool 2 before exporting')
    if generated is None:
        raise ValueError('Build Views & Vistas in Tool 3 before exporting')
    if not len(generated.all_objects):
        raise ValueError('AVV_Generated contains no geometry')
    unexpected = [o.name for o in generated.all_objects if not o.get('geolod_generated')]
    if unexpected:
        raise ValueError('Non-generated objects linked into AVV_Generated: ' + ', '.join(unexpected[:3]))
    registered = getattr(scene, 'geolod_edit_generated_collection', None)
    if registered is not None:
        raise ValueError('Views & Vistas are still attached to a temporary edit; restore the LOD first')
    return build_export_groups(generated.all_objects)


def choose_export_root(parent):
    """Make an independent, never-overwritten export run directory."""
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    base = f'Views_Vistas_Export_{stamp}'
    candidate = os.path.join(parent, base)
    idx = 2
    while os.path.exists(candidate):
        candidate = os.path.join(parent, f'{base}_{idx:02d}')
        idx += 1
    os.makedirs(candidate, exist_ok=False)
    return candidate


def write_index(root_dir, jobs_done, generated, scene, completed=True, message=''):
    columns = ['PARK_NAME', 'VIEW_ID', 'relative_obj_path', 'objects',
               'viewpoints', 'viewsheds', 'frustums', 'other']
    with open(os.path.join(root_dir, 'export_index.csv'), 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for job in jobs_done:
            c = job['counts']
            writer.writerow({'PARK_NAME': job['park'], 'VIEW_ID': job['view_id'],
                             'relative_obj_path': f"{job['folder']}/{job['stem']}.obj",
                             'objects': len(job['objects']), 'viewpoints': c.get('viewpoint', 0),
                             'viewsheds': c.get('viewshed', 0), 'frustums': c.get('frustum', 0),
                             'other': sum(v for k, v in c.items() if k not in ('viewpoint', 'viewshed', 'frustum'))})
    frame = str(generated.get('lod_source_frame') or '')
    info = {
        'status': 'complete' if completed else 'incomplete',
        'note': message,
        'exported_views': len(jobs_done),
        'source_collection': GENERATED_COLLECTION,
        'source_crs': str(generated.get('source_crs') or 'EPSG:7854'),
        'lod_source_frame': frame,
        'scene_origin': {},
        'obj_axes': {'forward': '+Y', 'up': '+Z', 'scale': 1.0},
        'obj_coordinates': (
            'EPSG:7854 projected Easting/Northing in metres, provided original LOD placement was correct'
            if frame == 'RAW_ENH' else
            'Scene-local metres; reconstruct projected coordinates by adding Tool 1 scene origin'
            if frame == 'SCENE_LOCAL' else
            'Unknown imported LOD coordinate frame; independently verify alignment'),
        'alignment_verified': False,
        'warning': 'Export does not prove surveyed LOD alignment or height datum. No reprojection is performed.',
    }
    if georef.has_anchor(scene):
        ox, oy, oz = georef.anchor(scene)
        info['scene_origin'] = {'easting_m': repr(ox), 'northing_m': repr(oy), 'height_m': repr(oz)}
    with open(os.path.join(root_dir, 'export_reference.json'), 'w', encoding='utf-8') as f:
        json.dump(info, f, indent=2, ensure_ascii=False)


class AVVOBJSettings(PropertyGroup):
    directory: StringProperty(
        name='Export Folder', subtype='DIR_PATH', default='',
        description='Parent folder for a new location-grouped OBJ export directory')


class AVV_OT_export_obj_batch(Operator):
    bl_idname = 'avv.export_obj_batch'
    bl_label = 'Export Views & Vistas OBJ'
    bl_description = 'Export location-grouped OBJ models after restoring the LOD; Y-forward and Z-up, no coordinate changes'
    bl_options = {'REGISTER'}  # External files cannot be undone with Blender Undo.

    def _prepare(self, context):
        if context.mode != 'OBJECT':
            raise ValueError('Switch to Object Mode before exporting')
        scene = context.scene
        generated = bpy.data.collections.get(GENERATED_COLLECTION)
        jobs = export_preflight(scene, generated)
        if not jobs:
            raise ValueError('No VIEW_ID groups available to export')
        requested = scene.avv_obj_settings.directory.strip()
        if not requested:
            raise ValueError('Choose an export folder in Tool 4')
        if requested.startswith('//') and not bpy.data.filepath:
            raise ValueError('Save the Blender project or choose an absolute output folder')
        parent = os.path.abspath(bpy.path.abspath(requested))
        if not os.path.isdir(parent):
            raise ValueError('Export folder does not exist; choose an existing folder')
        if not os.access(parent, os.W_OK):
            raise ValueError('Export folder is not writable')
        self._jobs = jobs
        self._index = 0
        self._completed = []
        self._generated = generated
        self._root_dir = choose_export_root(parent)
        self._temp_collection = None
        self._previous_objects = []
        self._timer = None
        self._progress_started = False
        # Temporary collection does not change object positions, parenting or
        # selections. It is used solely for the OBJ operator's collection filter.
        tmp = bpy.data.collections.new('AVV_OBJ_EXPORT_WORKING')
        try:
            scene.collection.children.link(tmp)
        except Exception:
            bpy.data.collections.remove(tmp)
            raise
        self._temp_collection = tmp
        context.window_manager.progress_begin(0, len(jobs))
        self._progress_started = True
        self._set_status(context, f'Exporting 0/{len(jobs)} views')

    @staticmethod
    def _set_status(context, value):
        context.window_manager.avv_obj_status = value

    def _next(self, context):
        job = self._jobs[self._index]
        temp = self._temp_collection
        # Unlink only from our temporary export collection. All original
        # membership, transforms, and active/selected objects are unchanged.
        for obj in self._previous_objects:
            temp.objects.unlink(obj)
        for obj in job['objects']:
            temp.objects.link(obj)
        self._previous_objects = job['objects']
        folder = os.path.join(self._root_dir, job['folder'])
        os.makedirs(folder, exist_ok=True)
        target = os.path.join(folder, job['stem'] + '.obj')
        result = bpy.ops.wm.obj_export(
            filepath=target,
            check_existing=False,
            export_selected_objects=False,
            collection=temp.name,
            forward_axis='Y',
            up_axis='Z',
            global_scale=1.0,
            apply_modifiers=True,
            apply_transform=True,
            export_uv=True,
            export_normals=True,
            export_materials=True,
            export_object_groups=True,
            export_eval_mode='DAG_EVAL_VIEWPORT',
        )
        if 'FINISHED' not in result:
            raise RuntimeError(f'Blender OBJ exporter did not finish for {job["view_id"]}')
        if not os.path.isfile(target):
            raise RuntimeError(f'OBJ file was not created for {job["view_id"]}')
        self._completed.append(job)
        self._index += 1
        context.window_manager.progress_update(self._index)
        self._set_status(context, f'Exporting {self._index}/{len(self._jobs)} views')

    def _cleanup(self, context):
        timer = getattr(self, '_timer', None)
        if timer is not None:
            try:
                context.window_manager.event_timer_remove(timer)
            finally:
                self._timer = None
        tmp = getattr(self, '_temp_collection', None)
        if tmp is not None:
            # First unlink from scene and collection; removing only this new
            # empty collection must not delete any referenced Blender objects.
            for obj in list(tmp.objects):
                tmp.objects.unlink(obj)
            try:
                context.scene.collection.children.unlink(tmp)
            except Exception:
                pass
            bpy.data.collections.remove(tmp)
            self._temp_collection = None
        if getattr(self, '_progress_started', False):
            context.window_manager.progress_end()
            self._progress_started = False

    def _finish(self, context, complete, message=''):
        index_exc = None
        try:
            write_index(self._root_dir, self._completed, self._generated, context.scene,
                        completed=complete, message=message)
        except Exception as exc:
            index_exc = exc
        try:
            self._cleanup(context)
        except Exception as exc:
            if index_exc is None:
                index_exc = exc
        self._set_status(context, '' if complete and index_exc is None else 'Export incomplete — see output folder')
        if index_exc:
            self.report({'ERROR'}, f'OBJ export index/cleanup error: {index_exc}')
            return {'CANCELLED'}
        if not complete:
            self.report({'WARNING'}, f'OBJ export incomplete ({len(self._completed)}/{len(self._jobs)}): {message[:110]}')
            return {'CANCELLED'}
        self.report({'INFO'}, f'Exported {len(self._completed)} Views & Vistas OBJ files to {self._root_dir}')
        return {'FINISHED'}

    def invoke(self, context, event):
        try:
            self._prepare(context)
            if context.window is None:
                # Blender background mode: do not create a timer with no window.
                while self._index < len(self._jobs):
                    self._next(context)
                return self._finish(context, True)
            self._timer = context.window_manager.event_timer_add(0.06, window=context.window)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception as exc:
            if hasattr(self, '_root_dir'):
                return self._finish(context, False, str(exc))
            self.report({'ERROR'}, 'OBJ export not started: ' + str(exc)[:180])
            return {'CANCELLED'}

    def execute(self, context):
        try:
            self._prepare(context)
            while self._index < len(self._jobs):
                self._next(context)
            return self._finish(context, True)
        except Exception as exc:
            if hasattr(self, '_root_dir'):
                return self._finish(context, False, str(exc))
            self.report({'ERROR'}, 'OBJ export not started: ' + str(exc)[:180])
            return {'CANCELLED'}

    def modal(self, context, event):
        if event.type == 'ESC':
            return self._finish(context, False, 'Cancelled by user (completed OBJ files were retained)')
        # bpy.types.Event does not expose an `event.timer` attribute in
        # Blender 5.x. The window manager dispatches TIMER events to modal
        # handlers; our own timer controls the normal cadence. A TIMER event
        # is sufficient to advance one export job, and avoids the AttributeError
        # that broke v1.3.0 on the first tick.
        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}
        try:
            self._next(context)
            if self._index >= len(self._jobs):
                return self._finish(context, True)
            return {'RUNNING_MODAL'}
        except Exception as exc:
            return self._finish(context, False, str(exc))


class AVV_PT_export_obj(Panel):
    bl_idname = 'AVV_PT_export_obj'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Adelaide GeoLOD'
    bl_label = '4. Export OBJ'
    bl_order = 4

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene.avv_obj_settings, 'directory', text='Folder')
        row = layout.row()
        row.enabled = bool(bpy.data.collections.get(GENERATED_COLLECTION)) and not lod.edit_active(context.scene)
        row.operator('avv.export_obj_batch', text='Export Views & Vistas', icon='EXPORT')
        status = context.window_manager.avv_obj_status
        if status:
            layout.label(text=status, icon='TIME')


CLASSES = (AVVOBJSettings, AVV_OT_export_obj_batch, AVV_PT_export_obj)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.avv_obj_settings = PointerProperty(type=AVVOBJSettings)
    bpy.types.WindowManager.avv_obj_status = StringProperty(default='', options={'SKIP_SAVE'})


def unregister():
    if hasattr(bpy.types.WindowManager, 'avv_obj_status'):
        del bpy.types.WindowManager.avv_obj_status
    if hasattr(bpy.types.Scene, 'avv_obj_settings'):
        del bpy.types.Scene.avv_obj_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
