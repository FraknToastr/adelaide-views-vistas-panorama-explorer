# v1.3.1 — Tool 4 export progress fix (2026-10-14)

- Corrected `AttributeError: 'Event' object has no attribute 'timer'` when clicking **Export Views & Vistas**.
- Removed unsupported `event.timer` reference from the modal handler. Blender `TIMER` events now advance the export queue one `VIEW_ID` at a time.
- Added regression tests with Blender-style events that omit `timer`, including a complete multi-view modal export, cleanup, cancellation, and non-timer events.
- No changes to Tools 1–3, OBJ options, grouping, coordinate preservation, or existing project data.
- Static/mocked tests only; live Blender 5.2 validation is still needed.

# Changelog

## v1.3.0 — Batch Views & Vistas OBJ export

- Added minimalist **Tool 4 — Export OBJ** with a folder picker and one batch-export button.
- Exports generated Views & Vistas only, grouped by `PARK_NAME` and `VIEW_ID` into a separate OBJ per view.
- Retains component names within each OBJ and uses the Blender 5.2 native exporter with +Y forward, +Z up, scale 1.
- Supports previously generated v1.2.x frustums that did not store `PARK_NAME`, by matching their `VIEW_ID` to point/viewshed metadata.
- New non-overwriting timestamped export directory, export index CSV and georeference JSON sidecar.
- Blocks export while Tool 2 has an un-restored temporary edit.
- Uses a temporary export-only collection; never moves LOD/AVV objects or changes user selections.
- Processes one view per Blender modal timer tick with progress feedback and Esc cancellation between files.
- Added regression tests for export grouping, API arguments, non-destructive export, collisions, incomplete runs and progress.
- Tool 3 now also saves `PARK_NAME` on newly generated frustums; no source data is bundled.


## v1.2.1 — Blender 5.2 registration hotfix

- Fixed `TypeError: bpy_struct.__new__(struct): expected a single argument` when clicking **Register Selected Building**.
- Replaced direct invocation of Blender operator constructors with shared ordinary-Python functions.
- Made one-click registration a single operator transaction, with existing safeguards and the minimalist interface intact.
- Added a Blender-like mock regression that refuses operator construction to catch this regression.
- No shapefiles bundled; Tool 1 origin and Tool 3 geometry workflow unchanged.
- Tests performed with mocks; live Blender 5.2 installation remains unverified.

# Changes — v1.2.0

- Replaced multi-mode georeferencing UI with a minimal, task-specific Adelaide workflow.
- **Tool 1:** both externally selected shapefiles; first valid viewpoint sets new project origin; no bundled data.
- **Tool 2:** one-click registration using the selected building and its non-generated LOD collection; always preserves the imported coordinates; uses reference mesh geometric centre for edit relocation. Retains prior registered/editing scenes.
- **Tool 3:** generates during active LOD editing. Chooses raw MGA versus scene-local frame from the LOD's original anchor relative to viewpoints. Refuses incompatible/ambiguous placements rather than guessing.
- Views & Vistas are generated into their own registered collection near `(0,0,0)`, restored with the LOD by a shared inverse translation, and follow subsequent editing sessions.
- All points, view polygons and viewing frustums built by fixed hidden defaults. Removed advanced drop-downs, feature filters and metadata readout labels from the interface.
- Safeguards for partial LOD scope, double transforms, old registrations, read-only objects, and staging/rebuild failures retained.
- Added mock Blender integration tests including 8,200 LOD objects and newly created geometry.

Not verified in a live Blender 5.x installation. The add-on does not assert surveyed LOD alignment.
